# Secrets Management

This backend never hardcodes secrets in `application.yml`, source code, or the Docker image.
Every sensitive value — DB password, JWT signing key, SMTP credentials — is read from an
**environment variable** at startup via Spring's `${VAR_NAME:?error message}` syntax.

## Fail-secure by design

Look at `src/main/resources/application.yml`:

```yaml
password: ${DB_PASSWORD}
secret: ${JWT_SECRET}
```

These properties have **no default value**. If the environment variable is missing, Spring
Boot's property resolution throws a `PlaceholderResolutionException` during context startup and
**the application refuses to start** — there is no blank/insecure fallback path. (Note: Spring's
placeholder syntax only supports `${VAR:default}` for defaults, not shell-style `${VAR:?message}`
— omitting the default entirely is what makes it required.)

Secrets are also never logged: `GlobalExceptionHandler` never serializes exception stack traces
into API responses, and no code path logs environment variables or request bodies containing
credentials.

## Local development

For local/dev use, copy `.env.example` to `.env`, fill in real values, and Docker Compose will
inject them as environment variables into the `app` container (see `docker-compose.yml`). This
keeps secrets in a git-ignored file rather than in source.

## Production: plugging in a real secret manager

The environment-variable contract (`DB_PASSWORD`, `JWT_SECRET`, `SMTP_PASSWORD`, etc.) is exactly
the interface most secret managers already speak, so wiring one in requires **no code changes** —
only how those environment variables get populated at deploy time changes:

| Secret Manager | How to wire it in |
|---|---|
| **HashiCorp Vault** | Add `spring-cloud-vault-config` and a `bootstrap.yml`/`spring.config.import=vault://` entry, or inject via Vault Agent sidecar writing to a `.env` file consumed by the container. |
| **AWS Secrets Manager** | Use the AWS Secrets Manager Spring Cloud config provider (`spring-cloud-aws-secrets-manager-config`), or inject via ECS task definition `secrets:` block, which populates container env vars directly from Secrets Manager ARNs — zero app changes needed. |
| **Azure Key Vault** | Add `spring-cloud-azure-starter-keyvault-config`; App Service "Key Vault references" can also inject values as app settings/env vars directly. |
| **Google Secret Manager** | Use `spring-cloud-gcp-starter-secretmanager`, or mount secrets as env vars via Cloud Run's native Secret Manager integration. |
| **Kubernetes** | Store values as a `Secret` object and reference them via `envFrom`/`valueFrom.secretKeyRef` in the Deployment spec — the app never needs to know Kubernetes is involved. |

Because every secret enters the app the same way (an environment variable checked at startup),
you can start with `.env` + Docker Compose locally and move to any of the above in production
without touching `application.yml` or any Java code.

## Rotation

- **JWT secret rotation**: rotating `JWT_SECRET` immediately invalidates all previously issued
  access tokens (they fail signature verification). Refresh tokens are unaffected since they are
  opaque, DB-stored, and independently revocable — call `/api/v1/auth/logout-all` for a user, or
  rotate on a maintenance window when short-lived access token invalidation is acceptable (default
  TTL is 15 minutes).
- **DB / SMTP credential rotation**: update the secret in your secret manager, then redeploy /
  restart the app so the new environment variable is picked up (Spring reads these once at
  startup, not dynamically — for zero-downtime rotation without restart, integrate a
  `spring-cloud-vault` renewable lease instead of static env injection).

## What is NOT covered by this document

Encryption of sensitive data *at rest* in the database (e.g. column-level encryption for passport
numbers) is not yet implemented and is a recommended next step before handling real passport data
in production — see the README "Suggested Next Steps" section.
