package com.skyroute.airbooking.service;

import com.skyroute.airbooking.entity.OtpVerification;
import com.skyroute.airbooking.mail.EmailService;
import com.skyroute.airbooking.repository.OtpVerificationRepository;
import com.skyroute.airbooking.service.impl.OtpServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OtpServiceImplTest {

    @Mock
    private OtpVerificationRepository otpRepository;

    @Mock
    private EmailService emailService;

    private OtpServiceImpl otpService;

    @BeforeEach
    void setUp() {
        otpService = new OtpServiceImpl(otpRepository, emailService);
        ReflectionTestUtils.setField(otpService, "ttlSeconds", 300L);
        ReflectionTestUtils.setField(otpService, "resendCooldownSeconds", 60L);
        ReflectionTestUtils.setField(otpService, "maxAttempts", 5);
    }

    @Test
    void generateAndSend_persistsHashedCodeAndEmailsPlainCode() {
        when(otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc(anyString(), anyString()))
                .thenReturn(Optional.empty());

        otpService.generateAndSend("user@example.com", "registration");

        ArgumentCaptor<OtpVerification> captor = ArgumentCaptor.forClass(OtpVerification.class);
        verify(otpRepository).save(captor.capture());
        OtpVerification saved = captor.getValue();

        // The stored value must never equal a plain 6-digit code — it must be a BCrypt hash.
        assertThat(saved.getCodeHash()).startsWith("$2a$");
        assertThat(saved.isVerified()).isFalse();

        verify(emailService).sendOtpEmail(eq("user@example.com"), anyString(), eq(5));
    }

    @Test
    void verify_withCorrectCode_returnsOk() {
        String plainCode = "123456";
        OtpVerification record = OtpVerification.builder()
                .target("user@example.com")
                .purpose("registration")
                .codeHash(BCrypt.hashpw(plainCode, BCrypt.gensalt(10)))
                .attempts(0)
                .maxAttempts(5)
                .verified(false)
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusMinutes(5))
                .build();
        when(otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc("user@example.com", "registration"))
                .thenReturn(Optional.of(record));

        OtpService.VerifyResult result = otpService.verify("user@example.com", "registration", plainCode);

        assertThat(result).isEqualTo(OtpService.VerifyResult.OK);
    }

    @Test
    void verify_withExpiredCode_returnsExpired() {
        OtpVerification record = OtpVerification.builder()
                .target("user@example.com")
                .purpose("registration")
                .codeHash(BCrypt.hashpw("123456", BCrypt.gensalt(10)))
                .attempts(0)
                .maxAttempts(5)
                .verified(false)
                .createdAt(LocalDateTime.now().minusMinutes(10))
                .expiresAt(LocalDateTime.now().minusMinutes(5))
                .build();
        when(otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc("user@example.com", "registration"))
                .thenReturn(Optional.of(record));

        OtpService.VerifyResult result = otpService.verify("user@example.com", "registration", "123456");

        assertThat(result).isEqualTo(OtpService.VerifyResult.EXPIRED);
    }

    @Test
    void verify_withWrongCode_returnsInvalidAndIncrementsAttempts() {
        OtpVerification record = OtpVerification.builder()
                .target("user@example.com")
                .purpose("registration")
                .codeHash(BCrypt.hashpw("123456", BCrypt.gensalt(10)))
                .attempts(0)
                .maxAttempts(5)
                .verified(false)
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusMinutes(5))
                .build();
        when(otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc("user@example.com", "registration"))
                .thenReturn(Optional.of(record));

        OtpService.VerifyResult result = otpService.verify("user@example.com", "registration", "000000");

        assertThat(result).isEqualTo(OtpService.VerifyResult.INVALID);
        assertThat(record.getAttempts()).isEqualTo(1);
    }
}
