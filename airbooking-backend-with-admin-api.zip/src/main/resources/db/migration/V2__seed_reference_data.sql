-- Cities (mirrors src/lib/data/cities.ts so search dropdowns match immediately)
INSERT INTO cities (code, name, country) VALUES
    ('AMD', 'Ahmedabad', 'India'),
    ('BOM', 'Mumbai', 'India'),
    ('DEL', 'Delhi', 'India'),
    ('BLR', 'Bengaluru', 'India'),
    ('MAA', 'Chennai', 'India'),
    ('CCU', 'Kolkata', 'India'),
    ('HYD', 'Hyderabad', 'India'),
    ('GOI', 'Goa', 'India'),
    ('DXB', 'Dubai', 'UAE'),
    ('LHR', 'London', 'United Kingdom'),
    ('JFK', 'New York', 'United States'),
    ('EWR', 'Newark', 'United States'),
    ('SIN', 'Singapore', 'Singapore'),
    ('SYD', 'Sydney', 'Australia'),
    ('HKG', 'Hong Kong', 'Hong Kong'),
    ('CPT', 'Cape Town', 'South Africa'),
    ('CDG', 'Paris', 'France'),
    ('USA', 'United States (generic)', 'United States')
ON CONFLICT (code) DO NOTHING;

INSERT INTO aircraft (model, total_seats) VALUES
    ('Boeing 777', 396),
    ('Airbus A380', 517),
    ('Boeing 787', 330),
    ('Airbus A350', 325)
ON CONFLICT DO NOTHING;

-- Demo flights (subset mirroring src/lib/data/flights.ts, extend freely via admin API)
INSERT INTO flights (id, from_code, to_code, depart_time, arrive_time, duration, stops, stop_label,
                      travel_class, fare_name, price_inr, baggage, hand_baggage, seat_selection,
                      upgrade_to_first, change_fee, refund_fee, aircraft_id, departure_date)
VALUES
    ('EK539-205', 'AMD', 'EWR', '04:25', '16:00', '22 hr 10 min', 1, '1 stop, 1 connection',
     'Business', 'Flex Plus', 385945.00, '2 x 32 Kg', '2 x 7 Kg', 'Complimentary',
     'Eligible', 'No charge', 'No charge', 2, CURRENT_DATE + INTERVAL '7 day'),
    ('EK539-209', 'AMD', 'USA', '04:25', '21:20', '24 hr 0 min', 1, '1 stop, 1 connection',
     'Business', 'Flex Plus', 397976.00, '2 x 32 Kg', '2 x 7 Kg', 'Complimentary',
     'Eligible', 'No charge', 'No charge', 2, CURRENT_DATE + INTERVAL '7 day'),
    ('EK112-330', 'AMD', 'LHR', '09:10', '21:45', '18 hr 35 min', 1, '1 stop, 1 connection',
     'Economy', 'Saver', 92450.00, '1 x 23 Kg', '1 x 7 Kg', 'Chargeable',
     'Not eligible', 'Chargeable', 'Non-refundable', 1, CURRENT_DATE + INTERVAL '5 day')
ON CONFLICT (id) DO NOTHING;

INSERT INTO flight_segments (flight_id, sequence_no, airline_code, flight_number, aircraft) VALUES
    ('EK539-205', 1, 'B77', 'EK539', 'Boeing 777'),
    ('EK539-205', 2, 'A380', 'EK205', 'Airbus A380'),
    ('EK539-209', 1, 'B77', 'EK539', 'Boeing 777'),
    ('EK539-209', 2, 'A380', 'EK209', 'Airbus A380'),
    ('EK112-330', 1, 'B77', 'EK112', 'Boeing 777'),
    ('EK112-330', 2, 'A380', 'EK330', 'Airbus A380');

-- Simple economy-tier seat map generator for the 3 demo flights (rows 1-30, A-F)
DO $$
DECLARE
    fl RECORD;
    r INT;
    c TEXT;
    cols TEXT[] := ARRAY['A','B','C','D','E','F'];
    tier TEXT;
    price NUMERIC;
BEGIN
    FOR fl IN SELECT id FROM flights LOOP
        FOR r IN 1..30 LOOP
            FOREACH c IN ARRAY cols LOOP
                IF r <= 3 THEN
                    tier := 'business'; price := 4500;
                ELSIF r <= 6 THEN
                    tier := 'premium'; price := 2200;
                ELSE
                    tier := 'economy'; price := 800;
                END IF;
                INSERT INTO seats (id, flight_id, row_no, col_letter, tier, price_inr,
                                    is_exit_row, is_window, is_aisle)
                VALUES (r || c, fl.id, r, c, tier, price,
                        (r = 12 OR r = 13),
                        (c = 'A' OR c = 'F'),
                        (c = 'C' OR c = 'D'))
                ON CONFLICT (flight_id, id) DO NOTHING;
            END LOOP;
        END LOOP;
    END LOOP;
END $$;
