-- =========================================================
-- SkyRoute Airlines - Initial Schema (PostgreSQL)
-- =========================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ---------------------------------------------------------
-- Roles & Users
-- ---------------------------------------------------------
CREATE TABLE roles (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(50)  NOT NULL UNIQUE,
    description VARCHAR(255)
);

INSERT INTO roles (name, description) VALUES
    ('ROLE_USER', 'Standard authenticated traveler'),
    ('ROLE_ADMIN', 'System administrator');

CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name          VARCHAR(100) NOT NULL,
    last_name           VARCHAR(100),
    email               VARCHAR(255) NOT NULL UNIQUE,
    phone               VARCHAR(20),
    password_hash       VARCHAR(255) NOT NULL,
    gender              VARCHAR(30),
    date_of_birth       DATE,
    nationality         VARCHAR(100),
    passport_number     VARCHAR(50),
    passport_expiry     DATE,
    passport_country    VARCHAR(100),
    address_line1       VARCHAR(255),
    address_line2       VARCHAR(255),
    city                VARCHAR(100),
    state               VARCHAR(100),
    postal_code         VARCHAR(20),
    country             VARCHAR(100),
    avatar_url          VARCHAR(500),
    email_verified      BOOLEAN NOT NULL DEFAULT FALSE,
    account_locked      BOOLEAN NOT NULL DEFAULT FALSE,
    account_locked_until TIMESTAMP,
    failed_login_count  INT NOT NULL DEFAULT 0,
    is_deleted          BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMP NOT NULL DEFAULT now(),
    updated_at          TIMESTAMP NOT NULL DEFAULT now(),
    version             BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX idx_users_email ON users (email) WHERE is_deleted = FALSE;

CREATE TABLE user_roles (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE password_history (
    id            BIGSERIAL PRIMARY KEY,
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- Refresh tokens / sessions / security events
-- ---------------------------------------------------------
CREATE TABLE refresh_tokens (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash   VARCHAR(255) NOT NULL UNIQUE,
    device_info  VARCHAR(255),
    ip_address   VARCHAR(64),
    issued_at    TIMESTAMP NOT NULL DEFAULT now(),
    expires_at   TIMESTAMP NOT NULL,
    revoked      BOOLEAN NOT NULL DEFAULT FALSE,
    revoked_at   TIMESTAMP,
    replaced_by  UUID
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens (user_id);

CREATE TABLE failed_login_attempts (
    id          BIGSERIAL PRIMARY KEY,
    email       VARCHAR(255) NOT NULL,
    ip_address  VARCHAR(64),
    attempted_at TIMESTAMP NOT NULL DEFAULT now(),
    reason      VARCHAR(255)
);

CREATE INDEX idx_failed_login_email ON failed_login_attempts (email, attempted_at);

CREATE TABLE security_events (
    id          BIGSERIAL PRIMARY KEY,
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    event_type  VARCHAR(100) NOT NULL,
    description VARCHAR(500),
    ip_address  VARCHAR(64),
    user_agent  VARCHAR(255),
    created_at  TIMESTAMP NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- OTP verification (hashed codes only)
-- ---------------------------------------------------------
CREATE TABLE otp_verifications (
    id           BIGSERIAL PRIMARY KEY,
    target       VARCHAR(255) NOT NULL,          -- email or phone
    purpose      VARCHAR(50) NOT NULL,            -- registration, password_reset, email_verification, mobile_verification
    code_hash    VARCHAR(255) NOT NULL,           -- never store plain OTP
    attempts     INT NOT NULL DEFAULT 0,
    max_attempts INT NOT NULL DEFAULT 5,
    verified     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMP NOT NULL DEFAULT now(),
    expires_at   TIMESTAMP NOT NULL
);

CREATE INDEX idx_otp_target_purpose ON otp_verifications (target, purpose);

-- ---------------------------------------------------------
-- Reference data: cities / airports
-- ---------------------------------------------------------
CREATE TABLE countries (
    code VARCHAR(3) PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE cities (
    code       VARCHAR(10) PRIMARY KEY,   -- IATA airport/city code, matches frontend City.code
    name       VARCHAR(100) NOT NULL,
    country    VARCHAR(100) NOT NULL
);

-- ---------------------------------------------------------
-- Aircraft / Flights / Segments / Seat classes / Seats
-- ---------------------------------------------------------
CREATE TABLE aircraft (
    id       BIGSERIAL PRIMARY KEY,
    model    VARCHAR(100) NOT NULL,        -- e.g. "Boeing 777", "Airbus A380"
    total_seats INT NOT NULL
);

CREATE TABLE seat_classes (
    id    BIGSERIAL PRIMARY KEY,
    name  VARCHAR(30) NOT NULL UNIQUE      -- Economy, Business, First (matches TravelClass)
);

INSERT INTO seat_classes (name) VALUES ('Economy'), ('Business'), ('First');

CREATE TABLE flights (
    id               VARCHAR(30) PRIMARY KEY,   -- matches frontend FlightOffer.id e.g. "EK539-205"
    from_code        VARCHAR(10) NOT NULL REFERENCES cities(code),
    to_code          VARCHAR(10) NOT NULL REFERENCES cities(code),
    depart_time      VARCHAR(10) NOT NULL,      -- "HH:mm" display value, matches frontend
    arrive_time      VARCHAR(10) NOT NULL,
    duration         VARCHAR(30) NOT NULL,
    stops            INT NOT NULL DEFAULT 0,
    stop_label       VARCHAR(100),
    travel_class     VARCHAR(30) NOT NULL,
    fare_name        VARCHAR(100),
    price_inr        NUMERIC(12,2) NOT NULL,
    baggage          VARCHAR(50),
    hand_baggage     VARCHAR(50),
    seat_selection   VARCHAR(50),
    upgrade_to_first VARCHAR(50),
    change_fee       VARCHAR(50),
    refund_fee       VARCHAR(50),
    aircraft_id      BIGINT REFERENCES aircraft(id),
    departure_date   DATE NOT NULL,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_flights_route_date ON flights (from_code, to_code, departure_date);

CREATE TABLE flight_segments (
    id            BIGSERIAL PRIMARY KEY,
    flight_id     VARCHAR(30) NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
    sequence_no   INT NOT NULL,
    airline_code  VARCHAR(10) NOT NULL,
    flight_number VARCHAR(20) NOT NULL,
    aircraft      VARCHAR(100)
);

CREATE TABLE seats (
    id           VARCHAR(20) NOT NULL,           -- e.g. "12A", matches frontend Seat.id
    flight_id    VARCHAR(30) NOT NULL REFERENCES flights(id) ON DELETE CASCADE,
    row_no       INT NOT NULL,
    col_letter   VARCHAR(2) NOT NULL,
    tier         VARCHAR(20) NOT NULL,           -- economy, premium, business, first
    price_inr    NUMERIC(10,2) NOT NULL,
    is_exit_row  BOOLEAN NOT NULL DEFAULT FALSE,
    is_window    BOOLEAN NOT NULL DEFAULT FALSE,
    is_aisle     BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (flight_id, id)
);

-- ---------------------------------------------------------
-- Bookings / Passengers
-- ---------------------------------------------------------
CREATE TABLE bookings (
    pnr             VARCHAR(10) PRIMARY KEY,
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
    flight_id       VARCHAR(30) NOT NULL REFERENCES flights(id),
    status          VARCHAR(30) NOT NULL DEFAULT 'pending_payment', -- pending_payment, confirmed, checked_in, cancelled
    contact_email   VARCHAR(255) NOT NULL,
    contact_phone   VARCHAR(20),
    total_amount    NUMERIC(12,2) NOT NULL,
    transaction_id  VARCHAR(50),
    is_deleted      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMP NOT NULL DEFAULT now(),
    updated_at      TIMESTAMP NOT NULL DEFAULT now(),
    version         BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX idx_bookings_user ON bookings (user_id);
CREATE INDEX idx_bookings_flight ON bookings (flight_id);

CREATE TABLE booking_passengers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_pnr     VARCHAR(10) NOT NULL REFERENCES bookings(pnr) ON DELETE CASCADE,
    full_name       VARCHAR(150) NOT NULL,
    phone           VARCHAR(20),
    email           VARCHAR(255),
    age             VARCHAR(5),
    gender          VARCHAR(30),
    senior_citizen  BOOLEAN NOT NULL DEFAULT FALSE,
    seat_id         VARCHAR(20),
    checked_in      BOOLEAN NOT NULL DEFAULT FALSE,
    boarding_seq    INT
);

CREATE INDEX idx_booking_passengers_booking ON booking_passengers (booking_pnr);

-- ---------------------------------------------------------
-- Payments / Transactions
-- ---------------------------------------------------------
CREATE TABLE payment_transactions (
    id            VARCHAR(50) PRIMARY KEY,       -- matches frontend Transaction.id
    booking_pnr   VARCHAR(10) NOT NULL REFERENCES bookings(pnr) ON DELETE CASCADE,
    method        VARCHAR(30) NOT NULL,           -- card, upi, netbanking, wallet
    method_label  VARCHAR(100),
    amount        NUMERIC(12,2) NOT NULL,
    status        VARCHAR(20) NOT NULL,           -- success, failed
    reference_id  VARCHAR(100),
    idempotency_key VARCHAR(100) UNIQUE,
    failure_reason  VARCHAR(255),
    created_at    TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_transactions_booking ON payment_transactions (booking_pnr);

-- ---------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------
CREATE TABLE notifications (
    id          BIGSERIAL PRIMARY KEY,
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       VARCHAR(255) NOT NULL,
    message     VARCHAR(1000) NOT NULL,
    type        VARCHAR(50) NOT NULL DEFAULT 'INFO',
    is_read     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX idx_notifications_user ON notifications (user_id, is_read);

-- ---------------------------------------------------------
-- Audit log (generic, append-only)
-- ---------------------------------------------------------
CREATE TABLE audit_logs (
    id           BIGSERIAL PRIMARY KEY,
    actor_user_id UUID,
    action       VARCHAR(100) NOT NULL,
    entity_type  VARCHAR(100),
    entity_id    VARCHAR(100),
    details      TEXT,
    ip_address   VARCHAR(64),
    created_at   TIMESTAMP NOT NULL DEFAULT now()
);
