package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.dto.request.CheckInRequest;
import com.skyroute.airbooking.dto.request.SeatChangeRequest;
import com.skyroute.airbooking.dto.response.BoardingPassResponse;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.service.CheckInService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/checkin")
@RequiredArgsConstructor
@Tag(name = "Check-in", description = "Web check-in and boarding pass generation (guest-accessible)")
public class CheckInController {

    private final CheckInService checkInService;

    @PostMapping("/lookup")
    public ApiResponse<BookingResponse> lookup(@Valid @RequestBody CheckInRequest request) {
        return ApiResponse.success("OK", checkInService.lookup(request));
    }

    @PostMapping
    public ApiResponse<List<BoardingPassResponse>> checkIn(@Valid @RequestBody CheckInRequest request) {
        return ApiResponse.success("Checked in successfully", checkInService.checkIn(request));
    }

    @PostMapping("/seat")
    public ApiResponse<BoardingPassResponse> changeSeat(@Valid @RequestBody SeatChangeRequest request) {
        return ApiResponse.success("Seat updated", checkInService.changeSeat(request));
    }
}
