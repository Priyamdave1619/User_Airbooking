package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.response.TransactionResponse;
import com.skyroute.airbooking.service.AdminPaymentService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/v1/admin/payments")
@RequiredArgsConstructor
@Tag(name = "Admin — Payments", description = "View every transaction across all users (ROLE_ADMIN only)")
public class AdminPaymentController {

    private final AdminPaymentService adminPaymentService;

    @GetMapping
    public ApiResponse<PageResponse<TransactionResponse>> list(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(page, size);
        return ApiResponse.success("OK", PageResponse.from(adminPaymentService.listTransactions(status, pageable)));
    }

    @GetMapping("/revenue")
    public ApiResponse<BigDecimal> totalRevenue() {
        return ApiResponse.success("OK", adminPaymentService.totalRevenue());
    }
}
