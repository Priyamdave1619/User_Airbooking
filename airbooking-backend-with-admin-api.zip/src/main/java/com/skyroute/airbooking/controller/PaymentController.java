package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.dto.response.TransactionResponse;
import com.skyroute.airbooking.security.SecurityUser;
import com.skyroute.airbooking.service.PaymentService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Tag(name = "Payments", description = "Process booking payments and view transaction history")
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ApiResponse<TransactionResponse> pay(@Valid @RequestBody ProcessPaymentRequest request) {
        TransactionResponse response = paymentService.processPayment(request);
        return ApiResponse.success("Payment successful", response);
    }

    @GetMapping("/booking/{pnr}")
    public ApiResponse<List<TransactionResponse>> bookingTransactions(@PathVariable String pnr) {
        return ApiResponse.success("OK", paymentService.getBookingTransactions(pnr));
    }

    @GetMapping("/me")
    public ApiResponse<List<TransactionResponse>> myTransactions(@AuthenticationPrincipal SecurityUser principal) {
        return ApiResponse.success("OK", paymentService.getMyTransactionHistory(principal.getId()));
    }
}
