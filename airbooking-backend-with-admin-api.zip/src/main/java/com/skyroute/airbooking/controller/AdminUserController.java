package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.admin.AdminUserResponse;
import com.skyroute.airbooking.dto.admin.SetAccountLockedRequest;
import com.skyroute.airbooking.dto.admin.UpdateUserRolesRequest;
import com.skyroute.airbooking.service.AdminUserService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin/users")
@RequiredArgsConstructor
@Tag(name = "Admin — Users", description = "Manage travelers: search, lock/unlock, roles (ROLE_ADMIN only)")
public class AdminUserController {

    private final AdminUserService adminUserService;

    @GetMapping
    public ApiResponse<PageResponse<AdminUserResponse>> list(
            @RequestParam(required = false) String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return ApiResponse.success("OK", PageResponse.from(adminUserService.listUsers(q, pageable)));
    }

    @GetMapping("/{id}")
    public ApiResponse<AdminUserResponse> get(@PathVariable UUID id) {
        return ApiResponse.success("OK", adminUserService.getUser(id));
    }

    @PatchMapping("/{id}/lock")
    public ApiResponse<AdminUserResponse> setLocked(@PathVariable UUID id, @Valid @RequestBody SetAccountLockedRequest request) {
        return ApiResponse.success(request.locked() ? "Account locked" : "Account unlocked",
                adminUserService.setAccountLocked(id, request.locked()));
    }

    @PutMapping("/{id}/roles")
    public ApiResponse<AdminUserResponse> setRoles(@PathVariable UUID id, @Valid @RequestBody UpdateUserRolesRequest request) {
        return ApiResponse.success("Roles updated", adminUserService.setRoles(id, request.roles()));
    }
}
