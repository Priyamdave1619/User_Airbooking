package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.response.NotificationResponse;
import com.skyroute.airbooking.security.SecurityUser;
import com.skyroute.airbooking.service.NotificationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications", description = "In-app notification inbox")
public class NotificationController {

    private final NotificationService notificationService;

    @GetMapping
    public ApiResponse<PageResponse<NotificationResponse>> list(
            @AuthenticationPrincipal SecurityUser principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return ApiResponse.success("OK", PageResponse.from(notificationService.getMyNotifications(principal.getId(), pageable)));
    }

    @PostMapping("/{id}/read")
    public ApiResponse<Void> markRead(@AuthenticationPrincipal SecurityUser principal, @PathVariable Long id) {
        notificationService.markAsRead(id, principal.getId());
        return ApiResponse.success("Marked as read");
    }
}
