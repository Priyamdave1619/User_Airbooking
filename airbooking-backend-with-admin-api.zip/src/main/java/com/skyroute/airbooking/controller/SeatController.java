package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.dto.request.SeatLockRequest;
import com.skyroute.airbooking.dto.response.SeatLockResponse;
import com.skyroute.airbooking.dto.response.SeatResponse;
import com.skyroute.airbooking.service.SeatService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/seats")
@RequiredArgsConstructor
@Tag(name = "Seats", description = "Live seat map and temporary seat holds")
public class SeatController {

    private final SeatService seatService;

    @GetMapping("/{flightId}")
    public ApiResponse<List<SeatResponse>> getSeatMap(@PathVariable String flightId,
                                                        @RequestParam String sessionId) {
        return ApiResponse.success("OK", seatService.getSeatMap(flightId, sessionId));
    }

    @PostMapping("/lock")
    public ApiResponse<SeatLockResponse> lockSeat(@Valid @RequestBody SeatLockRequest request) {
        SeatLockResponse response = seatService.lockSeat(request.flightId(), request.seatId(), request.sessionId());
        return ApiResponse.success("Seat held for 5 minutes", response);
    }

    @DeleteMapping("/lock")
    public ApiResponse<Void> releaseSeat(@Valid @RequestBody SeatLockRequest request) {
        seatService.releaseSeat(request.flightId(), request.seatId(), request.sessionId());
        return ApiResponse.success("Seat released");
    }

    @DeleteMapping("/lock/all")
    public ApiResponse<Void> releaseAll(@RequestParam String flightId, @RequestParam String sessionId) {
        seatService.releaseAllSeatsForSession(flightId, sessionId);
        return ApiResponse.success("All held seats released");
    }
}
