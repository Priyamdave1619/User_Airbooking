package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.service.AdminBookingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/bookings")
@RequiredArgsConstructor
@Tag(name = "Admin — Bookings", description = "View and manage every booking (ROLE_ADMIN only)")
public class AdminBookingController {

    private final AdminBookingService adminBookingService;

    @GetMapping
    public ApiResponse<PageResponse<BookingResponse>> list(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(page, size);
        return ApiResponse.success("OK", PageResponse.from(adminBookingService.listBookings(status, pageable)));
    }

    @GetMapping("/{pnr}")
    public ApiResponse<BookingResponse> get(@PathVariable String pnr) {
        return ApiResponse.success("OK", adminBookingService.getByPnr(pnr));
    }

    @PostMapping("/{pnr}/cancel")
    public ApiResponse<Void> cancel(@PathVariable String pnr) {
        adminBookingService.cancelBooking(pnr);
        return ApiResponse.success("Booking cancelled");
    }
}
