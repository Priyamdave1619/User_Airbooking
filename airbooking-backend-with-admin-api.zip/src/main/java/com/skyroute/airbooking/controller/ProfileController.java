package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.dto.request.UpdateProfileRequest;
import com.skyroute.airbooking.dto.response.UserResponse;
import com.skyroute.airbooking.security.SecurityUser;
import com.skyroute.airbooking.service.ProfileService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/profile")
@RequiredArgsConstructor
@Tag(name = "Profile", description = "View and update the current user's profile")
public class ProfileController {

    private final ProfileService profileService;

    @PutMapping
    public ApiResponse<UserResponse> update(@AuthenticationPrincipal SecurityUser principal,
                                             @RequestBody UpdateProfileRequest request) {
        return ApiResponse.success("Profile updated", profileService.updateProfile(principal.getId(), request));
    }

    @PutMapping("/avatar")
    public ApiResponse<UserResponse> updateAvatar(@AuthenticationPrincipal SecurityUser principal,
                                                   @RequestParam String avatarUrl) {
        return ApiResponse.success("Avatar updated", profileService.updateAvatar(principal.getId(), avatarUrl));
    }
}
