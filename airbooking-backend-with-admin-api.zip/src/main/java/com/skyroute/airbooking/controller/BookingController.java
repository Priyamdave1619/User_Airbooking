package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.request.CreateBookingRequest;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.security.SecurityUser;
import com.skyroute.airbooking.service.BookingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/bookings")
@RequiredArgsConstructor
@Tag(name = "Bookings", description = "Create, view, list, and cancel bookings")
public class BookingController {

    private final BookingService bookingService;

    @PostMapping
    public ApiResponse<BookingResponse> createBooking(@AuthenticationPrincipal SecurityUser principal,
                                                        @Valid @RequestBody CreateBookingRequest request) {
        BookingResponse response = bookingService.createBooking(request, principal.getId());
        return ApiResponse.success("Booking created. Complete payment to confirm your seats.", response);
    }

    @GetMapping("/{pnr}")
    public ApiResponse<BookingResponse> getByPnr(@PathVariable String pnr) {
        return ApiResponse.success("OK", bookingService.getByPnr(pnr));
    }

    @GetMapping("/me")
    public ApiResponse<PageResponse<BookingResponse>> myBookings(
            @AuthenticationPrincipal SecurityUser principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        var pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        return ApiResponse.success("OK", PageResponse.from(bookingService.getMyBookings(principal.getId(), pageable)));
    }

    @PostMapping("/{pnr}/cancel")
    public ApiResponse<Void> cancel(@AuthenticationPrincipal SecurityUser principal, @PathVariable String pnr) {
        bookingService.cancelBooking(pnr, principal.getId());
        return ApiResponse.success("Booking cancelled");
    }
}
