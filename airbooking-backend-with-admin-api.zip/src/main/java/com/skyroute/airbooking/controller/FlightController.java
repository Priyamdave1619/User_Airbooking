package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.dto.response.CityResponse;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import com.skyroute.airbooking.service.FlightService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Flights & Reference Data", description = "Flight search and city/airport lookups")
public class FlightController {

    private final FlightService flightService;

    @GetMapping("/cities")
    public ApiResponse<List<CityResponse>> getCities() {
        return ApiResponse.success("OK", flightService.getAllCities());
    }

    @GetMapping("/flights/search")
    public ApiResponse<List<FlightOfferResponse>> search(
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(required = false) String travelClass) {
        return ApiResponse.success("OK", flightService.search(from, to, date, travelClass));
    }

    @GetMapping("/flights/{id}")
    public ApiResponse<FlightOfferResponse> getById(@PathVariable String id) {
        return ApiResponse.success("OK", flightService.getById(id));
    }
}
