package com.skyroute.airbooking.controller;

import com.skyroute.airbooking.common.ApiResponse;
import com.skyroute.airbooking.common.PageResponse;
import com.skyroute.airbooking.dto.admin.AircraftRequest;
import com.skyroute.airbooking.dto.admin.AircraftResponse;
import com.skyroute.airbooking.dto.admin.CreateFlightRequest;
import com.skyroute.airbooking.dto.admin.SetFlightActiveRequest;
import com.skyroute.airbooking.dto.admin.UpdateFlightRequest;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import com.skyroute.airbooking.service.AdminFlightService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/flights")
@RequiredArgsConstructor
@Tag(name = "Admin — Flights", description = "Flight & aircraft inventory management (ROLE_ADMIN only)")
public class AdminFlightController {

    private final AdminFlightService adminFlightService;

    @GetMapping
    public ApiResponse<PageResponse<FlightOfferResponse>> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        var pageable = PageRequest.of(page, size);
        return ApiResponse.success("OK", PageResponse.from(adminFlightService.listFlights(pageable)));
    }

    @GetMapping("/{id}")
    public ApiResponse<FlightOfferResponse> get(@PathVariable String id) {
        return ApiResponse.success("OK", adminFlightService.getFlight(id));
    }

    @PostMapping
    public ApiResponse<FlightOfferResponse> create(@Valid @RequestBody CreateFlightRequest request) {
        return ApiResponse.success("Flight created", adminFlightService.createFlight(request));
    }

    @PutMapping("/{id}")
    public ApiResponse<FlightOfferResponse> update(@PathVariable String id, @Valid @RequestBody UpdateFlightRequest request) {
        return ApiResponse.success("Flight updated", adminFlightService.updateFlight(id, request));
    }

    @PatchMapping("/{id}/active")
    public ApiResponse<FlightOfferResponse> setActive(@PathVariable String id, @Valid @RequestBody SetFlightActiveRequest request) {
        return ApiResponse.success(request.active() ? "Flight activated" : "Flight deactivated",
                adminFlightService.setActive(id, request.active()));
    }

    @GetMapping("/aircraft")
    public ApiResponse<List<AircraftResponse>> listAircraft() {
        return ApiResponse.success("OK", adminFlightService.listAircraft());
    }

    @PostMapping("/aircraft")
    public ApiResponse<AircraftResponse> createAircraft(@Valid @RequestBody AircraftRequest request) {
        return ApiResponse.success("Aircraft created", adminFlightService.createAircraft(request));
    }
}
