package com.skyroute.airbooking.dto.admin;

import java.util.List;

public record AdminUserResponse(
        String id,
        String firstName,
        String lastName,
        String email,
        String phone,
        boolean emailVerified,
        boolean accountLocked,
        List<String> roles,
        long createdAt
) {
}
