package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;

public record SeatChangeRequest(
        @NotBlank String pnr,
        @NotBlank String passengerId,
        @NotBlank String newSeatId
) {
}
