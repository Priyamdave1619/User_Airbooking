package com.skyroute.airbooking.dto.response;

import java.math.BigDecimal;

public record SeatResponse(
        String id,
        int row,
        String col,
        String label,
        String tier,
        BigDecimal priceInr,
        boolean isExitRow,
        boolean isWindow,
        boolean isAisle,
        String status, // available, occupied, selected, locked
        Long lockedAtEpochMs,
        String lockedBy
) {
}
