package com.skyroute.airbooking.dto.response;

import java.math.BigDecimal;
import java.util.List;

public record BookingResponse(
        String pnr,
        String flightId,
        List<BookingPassengerResponse> passengers,
        String status,
        String contactEmail,
        String contactPhone,
        long createdAt,
        BigDecimal totalAmount,
        String transactionId
) {
}
