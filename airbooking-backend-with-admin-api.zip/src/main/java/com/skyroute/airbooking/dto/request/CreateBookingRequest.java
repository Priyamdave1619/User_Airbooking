package com.skyroute.airbooking.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record CreateBookingRequest(
        @NotBlank String flightId,
        @NotEmpty @Valid List<BookingPassengerRequest> passengers,
        @NotBlank @Email String contactEmail,
        @NotBlank String contactPhone,
        @NotBlank String sessionId
) {
}
