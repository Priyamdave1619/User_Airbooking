package com.skyroute.airbooking.dto.admin;

public record SetFlightActiveRequest(boolean active) {
}
