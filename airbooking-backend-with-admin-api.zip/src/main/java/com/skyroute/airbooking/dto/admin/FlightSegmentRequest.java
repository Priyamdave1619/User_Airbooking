package com.skyroute.airbooking.dto.admin;

import jakarta.validation.constraints.NotBlank;

public record FlightSegmentRequest(
        @NotBlank String airlineCode,
        @NotBlank String flightNumber,
        String aircraft
) {
}
