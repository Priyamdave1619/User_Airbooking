package com.skyroute.airbooking.dto.request;

public record UpdateProfileRequest(
        String firstName,
        String lastName,
        String phone,
        String gender,
        String dateOfBirth,
        String nationality,
        String passportNumber,
        String passportExpiry,
        String passportCountry,
        String addressLine1,
        String addressLine2,
        String city,
        String state,
        String postalCode,
        String country
) {
}
