package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;

public record BookingPassengerRequest(
        @NotBlank String fullName,
        String phone,
        String email,
        String age,
        String gender,
        boolean seniorCitizen,
        String seatId
) {
}
