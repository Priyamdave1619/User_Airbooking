package com.skyroute.airbooking.dto.admin;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record CreateFlightRequest(
        @NotBlank String id,
        @NotBlank String fromCode,
        @NotBlank String toCode,
        @NotBlank String departTime,
        @NotBlank String arriveTime,
        @NotBlank String duration,
        int stops,
        String stopLabel,
        @NotBlank String travelClass,
        String fareName,
        @NotNull BigDecimal priceInr,
        String baggage,
        String handBaggage,
        String seatSelection,
        String upgradeToFirst,
        String changeFee,
        String refundFee,
        Long aircraftId,
        @NotNull LocalDate departureDate,
        @NotEmpty @Valid List<FlightSegmentRequest> segments
) {
}
