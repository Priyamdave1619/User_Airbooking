package com.skyroute.airbooking.dto.admin;

public record AircraftResponse(Long id, String model, int totalSeats) {
}
