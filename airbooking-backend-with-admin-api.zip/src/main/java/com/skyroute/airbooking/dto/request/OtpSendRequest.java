package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;

public record OtpSendRequest(
        @NotBlank String target,
        @NotBlank String purpose // registration, password_reset, email_verification, mobile_verification
) {
}
