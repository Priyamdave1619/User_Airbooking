package com.skyroute.airbooking.dto.admin;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record AircraftRequest(
        @NotBlank String model,
        @Min(1) int totalSeats
) {
}
