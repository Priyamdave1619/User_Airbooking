package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record ProcessPaymentRequest(
        @NotBlank String pnr,
        @NotBlank String method, // card, upi, netbanking, wallet
        @NotNull BigDecimal amount,
        @NotBlank String idempotencyKey,
        // Method-specific fields — validated in the strategy implementation, never persisted raw.
        String cardNumberLast4,
        String upiId,
        String bankCode,
        String walletProvider
) {
}
