package com.skyroute.airbooking.dto.response;

public record BookingPassengerResponse(
        String id,
        String fullName,
        String phone,
        String email,
        String age,
        String gender,
        boolean seniorCitizen,
        String seatId,
        boolean checkedIn
) {
}
