package com.skyroute.airbooking.dto.response;

public record FlightSegmentResponse(String airlineCode, String flightNumber, String aircraft) {
}
