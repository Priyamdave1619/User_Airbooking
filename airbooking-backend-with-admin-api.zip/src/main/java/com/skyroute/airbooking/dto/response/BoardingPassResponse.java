package com.skyroute.airbooking.dto.response;

public record BoardingPassResponse(
        String pnr,
        String passengerName,
        String flightId,
        String fromCode,
        String toCode,
        String seatLabel,
        String travelClass,
        String gate,
        String boardingTime,
        String departTime,
        int seq
) {
}
