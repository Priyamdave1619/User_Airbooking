package com.skyroute.airbooking.dto.response;

public record CityResponse(String code, String name, String country) {
}
