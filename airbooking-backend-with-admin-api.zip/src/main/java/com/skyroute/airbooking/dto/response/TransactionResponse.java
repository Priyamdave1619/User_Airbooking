package com.skyroute.airbooking.dto.response;

import java.math.BigDecimal;

public record TransactionResponse(
        String id,
        String pnr,
        String method,
        BigDecimal amount,
        String status,
        long createdAt,
        String methodLabel,
        String referenceId
) {
}
