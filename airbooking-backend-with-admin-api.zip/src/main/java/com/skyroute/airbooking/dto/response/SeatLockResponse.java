package com.skyroute.airbooking.dto.response;

public record SeatLockResponse(String flightId, String seatId, String lockedBy, long lockedAtEpochMs, long ttlSeconds) {
}
