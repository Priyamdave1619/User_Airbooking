package com.skyroute.airbooking.dto.response;

public record NotificationResponse(
        Long id,
        String title,
        String message,
        String type,
        boolean read,
        long createdAt
) {
}
