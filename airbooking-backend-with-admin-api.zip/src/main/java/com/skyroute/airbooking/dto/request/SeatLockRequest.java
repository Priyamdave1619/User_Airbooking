package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;

public record SeatLockRequest(
        @NotBlank String flightId,
        @NotBlank String seatId,
        @NotBlank String sessionId
) {
}
