package com.skyroute.airbooking.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record OtpVerifyRequest(
        @NotBlank String target,
        @NotBlank String purpose,
        @NotBlank @Pattern(regexp = "\\d{6}", message = "OTP must be 6 digits") String code
) {
}
