package com.skyroute.airbooking.dto.response;

import java.util.List;

public record UserResponse(
        String id,
        String firstName,
        String lastName,
        String email,
        String phone,
        String gender,
        String dateOfBirth,
        String nationality,
        String passportNumber,
        String passportExpiry,
        String passportCountry,
        String addressLine1,
        String addressLine2,
        String city,
        String state,
        String postalCode,
        String country,
        String avatarUrl,
        boolean emailVerified,
        long createdAt,
        List<String> roles
) {
}
