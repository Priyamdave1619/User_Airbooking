package com.skyroute.airbooking.dto.admin;

public record SetAccountLockedRequest(boolean locked) {
}
