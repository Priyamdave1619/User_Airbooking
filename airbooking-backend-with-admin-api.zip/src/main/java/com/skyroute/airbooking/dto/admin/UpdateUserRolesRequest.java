package com.skyroute.airbooking.dto.admin;

import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record UpdateUserRolesRequest(
        @NotEmpty List<String> roles // e.g. ["ROLE_USER"], ["ROLE_USER", "ROLE_ADMIN"]
) {
}
