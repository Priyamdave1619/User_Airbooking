package com.skyroute.airbooking.dto.response;

import java.math.BigDecimal;
import java.util.List;

public record FlightOfferResponse(
        String id,
        String fromCode,
        String toCode,
        String duration,
        String departTime,
        String arriveTime,
        int stops,
        String stopLabel,
        List<FlightSegmentResponse> segments,
        String travelClass,
        String fareName,
        BigDecimal priceInr,
        String baggage,
        String handBaggage,
        String seatSelection,
        String upgradeToFirst,
        String changeFee,
        String refundFee
) {
}
