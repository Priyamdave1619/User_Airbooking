package com.skyroute.airbooking.dto.admin;

import com.skyroute.airbooking.dto.response.BookingResponse;

import java.math.BigDecimal;
import java.util.List;

public record AdminDashboardStatsResponse(
        long totalUsers,
        long totalFlights,
        long upcomingFlights,
        long totalBookings,
        long confirmedBookings,
        long checkedInBookings,
        long cancelledBookings,
        long pendingPaymentBookings,
        BigDecimal totalRevenue,
        List<BookingResponse> recentBookings
) {
}
