package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, UUID> {
    Optional<RefreshToken> findByTokenHash(String tokenHash);
    void deleteAllByUserId(UUID userId);

    @org.springframework.data.jpa.repository.Modifying
    @org.springframework.data.jpa.repository.Query(
        "update RefreshToken r set r.revoked = true, r.revokedAt = CURRENT_TIMESTAMP where r.user.id = :userId and r.revoked = false")
    void revokeAllForUser(UUID userId);
}
