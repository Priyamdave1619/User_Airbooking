package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.OtpVerification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface OtpVerificationRepository extends JpaRepository<OtpVerification, Long> {
    Optional<OtpVerification> findFirstByTargetAndPurposeOrderByCreatedAtDesc(String target, String purpose);
}
