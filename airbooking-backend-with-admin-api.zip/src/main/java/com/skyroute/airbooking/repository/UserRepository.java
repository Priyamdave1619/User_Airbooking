package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmailAndDeletedFalse(String email);
    boolean existsByEmailAndDeletedFalse(String email);

    // --- Admin ---
    Page<User> findByDeletedFalseOrderByCreatedAtDesc(Pageable pageable);

    @Query("select u from User u where u.deleted = false and (" +
           "lower(u.email) like lower(concat('%', :q, '%')) or " +
           "lower(u.firstName) like lower(concat('%', :q, '%')) or " +
           "lower(u.lastName) like lower(concat('%', :q, '%')))")
    Page<User> search(@Param("q") String q, Pageable pageable);

    long countByDeletedFalse();
}
