package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City, String> {
}
