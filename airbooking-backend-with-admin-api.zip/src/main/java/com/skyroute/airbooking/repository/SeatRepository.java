package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.Seat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SeatRepository extends JpaRepository<Seat, Seat.SeatId> {
    List<Seat> findByFlightIdOrderByRowNoAscColLetterAsc(String flightId);
}
