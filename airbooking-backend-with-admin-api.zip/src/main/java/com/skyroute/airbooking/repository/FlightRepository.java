package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.Flight;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FlightRepository extends JpaRepository<Flight, String> {

    @Query("select f from Flight f where f.from.code = :fromCode and f.to.code = :toCode " +
           "and f.departureDate = :date and f.active = true")
    List<Flight> search(@Param("fromCode") String fromCode,
                         @Param("toCode") String toCode,
                         @Param("date") LocalDate date);

    Optional<Flight> findByIdAndActiveTrue(String id);

    // --- Admin ---
    Page<Flight> findAllByOrderByDepartureDateDescIdAsc(Pageable pageable);
    long countByActiveTrue();
    long countByActiveTrueAndDepartureDateGreaterThanEqual(LocalDate date);
}
