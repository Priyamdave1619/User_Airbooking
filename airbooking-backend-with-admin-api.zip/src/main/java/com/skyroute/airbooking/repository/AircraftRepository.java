package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.Aircraft;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AircraftRepository extends JpaRepository<Aircraft, Long> {
}
