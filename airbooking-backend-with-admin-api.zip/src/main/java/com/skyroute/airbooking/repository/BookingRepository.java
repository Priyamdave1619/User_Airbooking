package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.Booking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BookingRepository extends JpaRepository<Booking, String> {
    Optional<Booking> findByPnrAndDeletedFalse(String pnr);
    Page<Booking> findByUser_IdAndDeletedFalseOrderByCreatedAtDesc(UUID userId, Pageable pageable);
    List<Booking> findByFlight_IdAndStatusNot(String flightId, String excludedStatus);
    Optional<Booking> findByPnrAndContactEmailIgnoreCaseAndDeletedFalse(String pnr, String contactEmail);

    // --- Admin ---
    Page<Booking> findByDeletedFalseOrderByCreatedAtDesc(Pageable pageable);
    Page<Booking> findByStatusAndDeletedFalseOrderByCreatedAtDesc(String status, Pageable pageable);
    long countByDeletedFalse();
    long countByStatusAndDeletedFalse(String status);
}
