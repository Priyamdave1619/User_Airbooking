package com.skyroute.airbooking.repository;

import com.skyroute.airbooking.entity.PaymentTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface PaymentTransactionRepository extends JpaRepository<PaymentTransaction, String> {
    List<PaymentTransaction> findByBooking_PnrOrderByCreatedAtDesc(String pnr);
    Optional<PaymentTransaction> findByIdempotencyKey(String idempotencyKey);
    List<PaymentTransaction> findByBooking_User_IdOrderByCreatedAtDesc(java.util.UUID userId);

    // --- Admin ---
    Page<PaymentTransaction> findAllByOrderByCreatedAtDesc(Pageable pageable);
    Page<PaymentTransaction> findByStatusOrderByCreatedAtDesc(String status, Pageable pageable);

    @org.springframework.data.jpa.repository.Query(
            "select coalesce(sum(t.amount), 0) from PaymentTransaction t where t.status = 'success'")
    BigDecimal sumSuccessfulAmount();
}
