package com.skyroute.airbooking.mapper;

import com.skyroute.airbooking.dto.response.UserResponse;
import com.skyroute.airbooking.entity.Role;
import com.skyroute.airbooking.entity.User;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;

@Component
public class UserMapper {

    public UserResponse toResponse(User user) {
        return new UserResponse(
                user.getId().toString(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhone(),
                user.getGender(),
                user.getDateOfBirth() != null ? user.getDateOfBirth().toString() : null,
                user.getNationality(),
                user.getPassportNumber(),
                user.getPassportExpiry() != null ? user.getPassportExpiry().toString() : null,
                user.getPassportCountry(),
                user.getAddressLine1(),
                user.getAddressLine2(),
                user.getCity(),
                user.getState(),
                user.getPostalCode(),
                user.getCountry(),
                user.getAvatarUrl(),
                user.isEmailVerified(),
                user.getCreatedAt() != null ? user.getCreatedAt().toInstant(ZoneOffset.UTC).toEpochMilli() : 0L,
                user.getRoles().stream().map(Role::getName).sorted().toList()
        );
    }
}
