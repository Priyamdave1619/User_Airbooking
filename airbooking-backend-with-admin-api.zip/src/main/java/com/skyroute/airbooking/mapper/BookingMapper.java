package com.skyroute.airbooking.mapper;

import com.skyroute.airbooking.dto.response.BookingPassengerResponse;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.entity.BookingPassenger;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;

@Component
public class BookingMapper {

    public BookingResponse toResponse(Booking booking) {
        return new BookingResponse(
                booking.getPnr(),
                booking.getFlight().getId(),
                booking.getPassengers().stream().map(this::toResponse).toList(),
                booking.getStatus(),
                booking.getContactEmail(),
                booking.getContactPhone(),
                booking.getCreatedAt() != null ? booking.getCreatedAt().toInstant(ZoneOffset.UTC).toEpochMilli() : 0L,
                booking.getTotalAmount(),
                booking.getTransactionId()
        );
    }

    public BookingPassengerResponse toResponse(BookingPassenger passenger) {
        return new BookingPassengerResponse(
                passenger.getId().toString(),
                passenger.getFullName(),
                passenger.getPhone(),
                passenger.getEmail(),
                passenger.getAge(),
                passenger.getGender(),
                passenger.isSeniorCitizen(),
                passenger.getSeatId(),
                passenger.isCheckedIn()
        );
    }
}
