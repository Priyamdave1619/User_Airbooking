package com.skyroute.airbooking.mapper;

import com.skyroute.airbooking.dto.response.CityResponse;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import com.skyroute.airbooking.dto.response.FlightSegmentResponse;
import com.skyroute.airbooking.entity.City;
import com.skyroute.airbooking.entity.Flight;
import org.springframework.stereotype.Component;

@Component
public class FlightMapper {

    public CityResponse toResponse(City city) {
        return new CityResponse(city.getCode(), city.getName(), city.getCountry());
    }

    public FlightOfferResponse toResponse(Flight flight) {
        return new FlightOfferResponse(
                flight.getId(),
                flight.getFrom().getCode(),
                flight.getTo().getCode(),
                flight.getDuration(),
                flight.getDepartTime(),
                flight.getArriveTime(),
                flight.getStops(),
                flight.getStopLabel(),
                flight.getSegments().stream()
                        .map(s -> new FlightSegmentResponse(s.getAirlineCode(), s.getFlightNumber(), s.getAircraft()))
                        .toList(),
                flight.getTravelClass(),
                flight.getFareName(),
                flight.getPriceInr(),
                flight.getBaggage(),
                flight.getHandBaggage(),
                flight.getSeatSelection(),
                flight.getUpgradeToFirst(),
                flight.getChangeFee(),
                flight.getRefundFee()
        );
    }
}
