package com.skyroute.airbooking.mapper;

import com.skyroute.airbooking.dto.response.TransactionResponse;
import com.skyroute.airbooking.entity.PaymentTransaction;
import org.springframework.stereotype.Component;

import java.time.ZoneOffset;

@Component
public class TransactionMapper {

    public TransactionResponse toResponse(PaymentTransaction tx) {
        return new TransactionResponse(
                tx.getId(),
                tx.getBooking().getPnr(),
                tx.getMethod(),
                tx.getAmount(),
                tx.getStatus(),
                tx.getCreatedAt() != null ? tx.getCreatedAt().toInstant(ZoneOffset.UTC).toEpochMilli() : 0L,
                tx.getMethodLabel(),
                tx.getReferenceId()
        );
    }
}
