package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.exception.BadRequestException;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class UpiPaymentGateway implements PaymentGateway {

    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public String getMethodCode() {
        return "upi";
    }

    @Override
    public PaymentGatewayResult charge(ProcessPaymentRequest request) {
        if (request.upiId() == null || !request.upiId().matches("^[\\w.\\-]{2,}@[a-zA-Z]{2,}$")) {
            throw new BadRequestException("A valid UPI ID is required");
        }
        boolean success = RANDOM.nextInt(100) < 97;
        if (!success) {
            return new PaymentGatewayResult(false, null, "UPI: " + request.upiId(), "UPI transaction timed out");
        }
        String referenceId = "UPI-" + System.currentTimeMillis() + "-" + RANDOM.nextInt(9999);
        return new PaymentGatewayResult(true, referenceId, "UPI: " + request.upiId(), null);
    }
}
