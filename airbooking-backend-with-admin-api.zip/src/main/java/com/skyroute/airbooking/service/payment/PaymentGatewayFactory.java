package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.exception.BadRequestException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class PaymentGatewayFactory {

    private final Map<String, PaymentGateway> gatewaysByMethod;

    public PaymentGatewayFactory(List<PaymentGateway> gateways) {
        this.gatewaysByMethod = gateways.stream()
                .collect(Collectors.toMap(PaymentGateway::getMethodCode, g -> g));
    }

    public PaymentGateway resolve(String method) {
        PaymentGateway gateway = gatewaysByMethod.get(method);
        if (gateway == null) {
            throw new BadRequestException("Unsupported payment method: " + method);
        }
        return gateway;
    }
}
