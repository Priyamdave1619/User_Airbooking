package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.dto.response.TransactionResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.entity.PaymentTransaction;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.PaymentFailedException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.mail.EmailService;
import com.skyroute.airbooking.mapper.TransactionMapper;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.repository.PaymentTransactionRepository;
import com.skyroute.airbooking.service.PaymentService;
import com.skyroute.airbooking.service.payment.PaymentGateway;
import com.skyroute.airbooking.service.payment.PaymentGatewayFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private static final SecureRandom RANDOM = new SecureRandom();

    private final BookingRepository bookingRepository;
    private final PaymentTransactionRepository transactionRepository;
    private final PaymentGatewayFactory gatewayFactory;
    private final TransactionMapper transactionMapper;
    private final EmailService emailService;

    @Override
    @Transactional
    public TransactionResponse processPayment(ProcessPaymentRequest request) {
        // Idempotency: if this key was already processed, return the prior result rather than
        // charging twice (protects against client retries / double taps on "Pay Now").
        var existing = transactionRepository.findByIdempotencyKey(request.idempotencyKey());
        if (existing.isPresent()) {
            return transactionMapper.toResponse(existing.get());
        }

        Booking booking = bookingRepository.findByPnrAndDeletedFalse(request.pnr())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for PNR: " + request.pnr()));

        if (!"pending_payment".equals(booking.getStatus())) {
            throw new BadRequestException("This booking is not awaiting payment (status: " + booking.getStatus() + ")");
        }
        if (request.amount().compareTo(booking.getTotalAmount()) != 0) {
            throw new BadRequestException("Payment amount does not match the booking total");
        }

        PaymentGateway gateway = gatewayFactory.resolve(request.method());
        PaymentGateway.PaymentGatewayResult result = gateway.charge(request);

        String txId = "TXN-" + System.currentTimeMillis() + "-" + RANDOM.nextInt(99999);
        PaymentTransaction transaction = PaymentTransaction.builder()
                .id(txId)
                .booking(booking)
                .method(request.method())
                .methodLabel(result.methodLabel())
                .amount(request.amount())
                .status(result.success() ? "success" : "failed")
                .referenceId(result.referenceId())
                .idempotencyKey(request.idempotencyKey())
                .failureReason(result.failureReason())
                .createdAt(LocalDateTime.now())
                .build();
        transactionRepository.save(transaction);

        if (!result.success()) {
            throw new PaymentFailedException(result.failureReason() != null ? result.failureReason() : "Payment failed");
        }

        booking.setStatus("confirmed");
        booking.setTransactionId(txId);
        bookingRepository.save(booking);

        emailService.sendBookingConfirmationEmail(
                booking.getContactEmail(), booking.getPnr(), booking.getFlight().getId(),
                booking.getFlight().getFrom().getCode(), booking.getFlight().getTo().getCode(),
                booking.getTotalAmount().toPlainString());

        return transactionMapper.toResponse(transaction);
    }

    @Override
    public List<TransactionResponse> getBookingTransactions(String pnr) {
        return transactionRepository.findByBooking_PnrOrderByCreatedAtDesc(pnr).stream()
                .map(transactionMapper::toResponse).toList();
    }

    @Override
    public List<TransactionResponse> getMyTransactionHistory(UUID userId) {
        return transactionRepository.findByBooking_User_IdOrderByCreatedAtDesc(userId).stream()
                .map(transactionMapper::toResponse).toList();
    }
}
