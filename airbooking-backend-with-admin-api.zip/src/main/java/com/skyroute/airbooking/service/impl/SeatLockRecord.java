package com.skyroute.airbooking.service.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Value object persisted in Redis for an active seat hold. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SeatLockRecord {
    private String flightId;
    private String seatId;
    private String lockedBy; // session id
    private long lockedAtEpochMs;
}
