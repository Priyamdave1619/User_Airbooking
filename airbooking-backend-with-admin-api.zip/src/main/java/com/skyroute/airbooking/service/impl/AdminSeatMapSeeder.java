package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.entity.Seat;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Builds the standard economy/premium/business seat map (rows 1-30, A-F) for
 * a flight, mirroring the layout the V2 SQL migration seeds for demo
 * flights. Used when an admin creates a new flight through the API. */
@Component
public class AdminSeatMapSeeder {

    private static final String[] COLUMNS = {"A", "B", "C", "D", "E", "F"};

    public List<Seat> buildSeatsFor(String flightId) {
        List<Seat> seats = new ArrayList<>();
        for (int row = 1; row <= 30; row++) {
            String tier;
            BigDecimal price;
            if (row <= 3) {
                tier = "business";
                price = new BigDecimal("4500");
            } else if (row <= 6) {
                tier = "premium";
                price = new BigDecimal("2200");
            } else {
                tier = "economy";
                price = new BigDecimal("800");
            }

            for (String col : COLUMNS) {
                seats.add(Seat.builder()
                        .id(row + col)
                        .flightId(flightId)
                        .rowNo(row)
                        .colLetter(col)
                        .tier(tier)
                        .priceInr(price)
                        .exitRow(row == 12 || row == 13)
                        .window(col.equals("A") || col.equals("F"))
                        .aisle(col.equals("C") || col.equals("D"))
                        .build());
            }
        }
        return seats;
    }
}
