package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.exception.BadRequestException;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

/**
 * Mock card gateway. Swap for a real Stripe/adapter later — the interface
 * contract (charge -> PaymentGatewayResult) stays identical.
 * NOTE: full card numbers/CVV are intentionally never accepted here or
 * persisted anywhere; only a non-sensitive last-4 reference is stored.
 */
@Component
public class CardPaymentGateway implements PaymentGateway {

    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public String getMethodCode() {
        return "card";
    }

    @Override
    public PaymentGatewayResult charge(ProcessPaymentRequest request) {
        if (request.cardNumberLast4() == null || !request.cardNumberLast4().matches("\\d{4}")) {
            throw new BadRequestException("A valid card reference is required");
        }
        boolean success = RANDOM.nextInt(100) < 95; // simulate ~95% success, mirrors typical gateway behavior
        if (!success) {
            return new PaymentGatewayResult(false, null, "Card ending " + request.cardNumberLast4(),
                    "Card issuer declined the transaction");
        }
        String referenceId = "CARD-" + System.currentTimeMillis() + "-" + RANDOM.nextInt(9999);
        return new PaymentGatewayResult(true, referenceId, "Card ending " + request.cardNumberLast4(), null);
    }
}
