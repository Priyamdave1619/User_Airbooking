package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.response.TransactionResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;

public interface AdminPaymentService {

    Page<TransactionResponse> listTransactions(String status, Pageable pageable);

    BigDecimal totalRevenue();
}
