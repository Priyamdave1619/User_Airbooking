package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.admin.AdminDashboardStatsResponse;
import com.skyroute.airbooking.mapper.BookingMapper;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.repository.FlightRepository;
import com.skyroute.airbooking.repository.PaymentTransactionRepository;
import com.skyroute.airbooking.repository.UserRepository;
import com.skyroute.airbooking.service.AdminDashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class AdminDashboardServiceImpl implements AdminDashboardService {

    private final UserRepository userRepository;
    private final FlightRepository flightRepository;
    private final BookingRepository bookingRepository;
    private final PaymentTransactionRepository paymentTransactionRepository;
    private final BookingMapper bookingMapper;

    @Override
    public AdminDashboardStatsResponse getStats() {
        var recent = bookingRepository
                .findByDeletedFalseOrderByCreatedAtDesc(PageRequest.of(0, 5, Sort.by(Sort.Direction.DESC, "createdAt")))
                .map(bookingMapper::toResponse)
                .getContent();

        return new AdminDashboardStatsResponse(
                userRepository.countByDeletedFalse(),
                flightRepository.count(),
                flightRepository.countByActiveTrueAndDepartureDateGreaterThanEqual(LocalDate.now()),
                bookingRepository.countByDeletedFalse(),
                bookingRepository.countByStatusAndDeletedFalse("confirmed"),
                bookingRepository.countByStatusAndDeletedFalse("checked_in"),
                bookingRepository.countByStatusAndDeletedFalse("cancelled"),
                bookingRepository.countByStatusAndDeletedFalse("pending_payment"),
                paymentTransactionRepository.sumSuccessfulAmount(),
                recent
        );
    }
}
