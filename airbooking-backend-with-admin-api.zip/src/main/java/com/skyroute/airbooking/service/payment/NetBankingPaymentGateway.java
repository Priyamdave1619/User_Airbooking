package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.exception.BadRequestException;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class NetBankingPaymentGateway implements PaymentGateway {

    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public String getMethodCode() {
        return "netbanking";
    }

    @Override
    public PaymentGatewayResult charge(ProcessPaymentRequest request) {
        if (request.bankCode() == null || request.bankCode().isBlank()) {
            throw new BadRequestException("A bank must be selected for net banking");
        }
        boolean success = RANDOM.nextInt(100) < 96;
        if (!success) {
            return new PaymentGatewayResult(false, null, "NetBanking: " + request.bankCode(), "Bank server did not authorize the transaction");
        }
        String referenceId = "NB-" + System.currentTimeMillis() + "-" + RANDOM.nextInt(9999);
        return new PaymentGatewayResult(true, referenceId, "NetBanking: " + request.bankCode(), null);
    }
}
