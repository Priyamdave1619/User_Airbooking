package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.response.SeatLockResponse;
import com.skyroute.airbooking.dto.response.SeatResponse;

import java.util.List;

public interface SeatService {

    /** Full seat map for a flight with live status: available / occupied / selected / locked. */
    List<SeatResponse> getSeatMap(String flightId, String requestingSessionId);

    /** Attempts to place a temporary hold on a seat. Throws SeatUnavailableException if already held/occupied. */
    SeatLockResponse lockSeat(String flightId, String seatId, String sessionId);

    void releaseSeat(String flightId, String seatId, String sessionId);

    void releaseAllSeatsForSession(String flightId, String sessionId);
}
