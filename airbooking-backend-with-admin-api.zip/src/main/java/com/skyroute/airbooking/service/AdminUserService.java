package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.admin.AdminUserResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface AdminUserService {

    Page<AdminUserResponse> listUsers(String query, Pageable pageable);

    AdminUserResponse getUser(UUID id);

    AdminUserResponse setAccountLocked(UUID id, boolean locked);

    AdminUserResponse setRoles(UUID id, List<String> roleNames);
}
