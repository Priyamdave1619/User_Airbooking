package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.admin.AdminUserResponse;
import com.skyroute.airbooking.entity.Role;
import com.skyroute.airbooking.entity.User;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.repository.RoleRepository;
import com.skyroute.airbooking.repository.UserRepository;
import com.skyroute.airbooking.service.AdminUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdminUserServiceImpl implements AdminUserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    @Override
    public Page<AdminUserResponse> listUsers(String query, Pageable pageable) {
        Page<User> page = (query == null || query.isBlank())
                ? userRepository.findByDeletedFalseOrderByCreatedAtDesc(pageable)
                : userRepository.search(query, pageable);
        return page.map(this::toResponse);
    }

    @Override
    public AdminUserResponse getUser(UUID id) {
        return toResponse(findUserOrThrow(id));
    }

    @Override
    @Transactional
    public AdminUserResponse setAccountLocked(UUID id, boolean locked) {
        User user = findUserOrThrow(id);
        user.setAccountLocked(locked);
        if (!locked) {
            user.setFailedLoginCount(0);
            user.setAccountLockedUntil(null);
        }
        return toResponse(userRepository.save(user));
    }

    @Override
    @Transactional
    public AdminUserResponse setRoles(UUID id, List<String> roleNames) {
        User user = findUserOrThrow(id);
        Set<Role> roles = new HashSet<>();
        for (String name : roleNames) {
            roles.add(roleRepository.findByName(name)
                    .orElseThrow(() -> new BadRequestException("Unknown role: " + name)));
        }
        user.setRoles(roles);
        return toResponse(userRepository.save(user));
    }

    private User findUserOrThrow(UUID id) {
        return userRepository.findById(id)
                .filter(u -> !u.isDeleted())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
    }

    private AdminUserResponse toResponse(User user) {
        return new AdminUserResponse(
                user.getId().toString(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhone(),
                user.isEmailVerified(),
                user.isAccountLocked(),
                user.getRoles().stream().map(Role::getName).sorted().toList(),
                user.getCreatedAt() != null ? user.getCreatedAt().toInstant(ZoneOffset.UTC).toEpochMilli() : 0L
        );
    }
}
