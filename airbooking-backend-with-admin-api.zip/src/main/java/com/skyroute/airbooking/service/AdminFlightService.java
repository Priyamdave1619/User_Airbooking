package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.admin.AircraftRequest;
import com.skyroute.airbooking.dto.admin.AircraftResponse;
import com.skyroute.airbooking.dto.admin.CreateFlightRequest;
import com.skyroute.airbooking.dto.admin.UpdateFlightRequest;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AdminFlightService {

    Page<FlightOfferResponse> listFlights(Pageable pageable);

    FlightOfferResponse getFlight(String id);

    FlightOfferResponse createFlight(CreateFlightRequest request);

    FlightOfferResponse updateFlight(String id, UpdateFlightRequest request);

    FlightOfferResponse setActive(String id, boolean active);

    List<AircraftResponse> listAircraft();

    AircraftResponse createAircraft(AircraftRequest request);
}
