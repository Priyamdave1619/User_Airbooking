package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.response.TransactionResponse;
import com.skyroute.airbooking.mapper.TransactionMapper;
import com.skyroute.airbooking.repository.PaymentTransactionRepository;
import com.skyroute.airbooking.service.AdminPaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class AdminPaymentServiceImpl implements AdminPaymentService {

    private final PaymentTransactionRepository paymentTransactionRepository;
    private final TransactionMapper transactionMapper;

    @Override
    public Page<TransactionResponse> listTransactions(String status, Pageable pageable) {
        var page = (status == null || status.isBlank())
                ? paymentTransactionRepository.findAllByOrderByCreatedAtDesc(pageable)
                : paymentTransactionRepository.findByStatusOrderByCreatedAtDesc(status, pageable);
        return page.map(transactionMapper::toResponse);
    }

    @Override
    public BigDecimal totalRevenue() {
        return paymentTransactionRepository.sumSuccessfulAmount();
    }
}
