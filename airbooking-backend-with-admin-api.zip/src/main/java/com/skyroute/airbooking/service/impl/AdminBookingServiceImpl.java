package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.mapper.BookingMapper;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.service.AdminBookingService;
import com.skyroute.airbooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminBookingServiceImpl implements AdminBookingService {

    private final BookingRepository bookingRepository;
    private final BookingMapper bookingMapper;
    private final BookingService bookingService;

    @Override
    public Page<BookingResponse> listBookings(String status, Pageable pageable) {
        Page<Booking> page = (status == null || status.isBlank())
                ? bookingRepository.findByDeletedFalseOrderByCreatedAtDesc(pageable)
                : bookingRepository.findByStatusAndDeletedFalseOrderByCreatedAtDesc(status, pageable);
        return page.map(bookingMapper::toResponse);
    }

    @Override
    public BookingResponse getByPnr(String pnr) {
        Booking booking = bookingRepository.findByPnrAndDeletedFalse(pnr)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for PNR: " + pnr));
        return bookingMapper.toResponse(booking);
    }

    @Override
    public void cancelBooking(String pnr) {
        // null userId bypasses the ownership check — an admin can cancel any booking.
        bookingService.cancelBooking(pnr, null);
    }
}
