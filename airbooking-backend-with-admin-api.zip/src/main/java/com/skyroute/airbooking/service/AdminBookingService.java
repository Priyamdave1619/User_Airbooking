package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.response.BookingResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AdminBookingService {

    Page<BookingResponse> listBookings(String status, Pageable pageable);

    BookingResponse getByPnr(String pnr);

    void cancelBooking(String pnr);
}
