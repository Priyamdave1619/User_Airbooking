package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.request.BookingPassengerRequest;
import com.skyroute.airbooking.dto.request.CreateBookingRequest;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.entity.BookingPassenger;
import com.skyroute.airbooking.entity.Flight;
import com.skyroute.airbooking.entity.Seat;
import com.skyroute.airbooking.entity.User;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.ForbiddenException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.exception.SeatUnavailableException;
import com.skyroute.airbooking.mail.EmailService;
import com.skyroute.airbooking.mapper.BookingMapper;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.repository.FlightRepository;
import com.skyroute.airbooking.repository.SeatRepository;
import com.skyroute.airbooking.repository.UserRepository;
import com.skyroute.airbooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private static final String PNR_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final BookingRepository bookingRepository;
    private final FlightRepository flightRepository;
    private final SeatRepository seatRepository;
    private final UserRepository userRepository;
    private final SeatServiceImpl seatService; // for clearing locks post-booking
    private final BookingMapper bookingMapper;
    private final EmailService emailService;

    @Override
    @Transactional
    public BookingResponse createBooking(CreateBookingRequest request, UUID userId) {
        Flight flight = flightRepository.findByIdAndActiveTrue(request.flightId())
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + request.flightId()));

        List<Seat> flightSeats = seatRepository.findByFlightIdOrderByRowNoAscColLetterAsc(flight.getId());
        Map<String, Seat> seatsById = flightSeats.stream()
                .collect(java.util.stream.Collectors.toMap(Seat::getId, s -> s));

        List<Booking> existingActive = bookingRepository.findByFlight_IdAndStatusNot(flight.getId(), "cancelled");
        var occupiedSeatIds = existingActive.stream()
                .flatMap(b -> b.getPassengers().stream())
                .map(BookingPassenger::getSeatId)
                .filter(java.util.Objects::nonNull)
                .collect(java.util.stream.Collectors.toSet());

        BigDecimal total = flight.getPriceInr().multiply(BigDecimal.valueOf(request.passengers().size()));

        User user = userId != null ? userRepository.findById(userId).orElse(null) : null;

        Booking booking = Booking.builder()
                .pnr(generateUniquePnr())
                .user(user)
                .flight(flight)
                .status("pending_payment")
                .contactEmail(request.contactEmail())
                .contactPhone(request.contactPhone())
                .totalAmount(total)
                .build();

        List<BookingPassenger> passengers = new ArrayList<>();
        List<String> seatIdsToConfirm = new ArrayList<>();

        for (BookingPassengerRequest p : request.passengers()) {
            if (p.seatId() != null && !p.seatId().isBlank()) {
                Seat seat = seatsById.get(p.seatId());
                if (seat == null) {
                    throw new BadRequestException("Seat " + p.seatId() + " does not exist on this flight");
                }
                if (occupiedSeatIds.contains(p.seatId())) {
                    throw new SeatUnavailableException("Seat " + p.seatId() + " is no longer available");
                }
                total = total.add(seat.getPriceInr());
                seatIdsToConfirm.add(p.seatId());
            }
            passengers.add(BookingPassenger.builder()
                    .booking(booking)
                    .fullName(p.fullName())
                    .phone(p.phone())
                    .email(p.email())
                    .age(p.age())
                    .gender(p.gender())
                    .seniorCitizen(p.seniorCitizen())
                    .seatId(p.seatId())
                    .checkedIn(false)
                    .build());
        }

        booking.setTotalAmount(total);
        booking.setPassengers(passengers);
        Booking saved = bookingRepository.save(booking);

        // The booking record itself now reserves these seats; the temporary Redis hold can go.
        if (!seatIdsToConfirm.isEmpty()) {
            seatService.clearLocksForSeats(flight.getId(), seatIdsToConfirm);
        }

        return bookingMapper.toResponse(saved);
    }

    @Override
    public BookingResponse getByPnr(String pnr) {
        Booking booking = bookingRepository.findByPnrAndDeletedFalse(pnr)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for PNR: " + pnr));
        return bookingMapper.toResponse(booking);
    }

    @Override
    public Page<BookingResponse> getMyBookings(UUID userId, Pageable pageable) {
        return bookingRepository.findByUser_IdAndDeletedFalseOrderByCreatedAtDesc(userId, pageable)
                .map(bookingMapper::toResponse);
    }

    @Override
    @Transactional
    public void cancelBooking(String pnr, UUID userId) {
        Booking booking = bookingRepository.findByPnrAndDeletedFalse(pnr)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for PNR: " + pnr));

        if (userId != null && booking.getUser() != null && !booking.getUser().getId().equals(userId)) {
            throw new ForbiddenException("You do not have permission to cancel this booking");
        }
        if ("cancelled".equals(booking.getStatus())) {
            throw new BadRequestException("This booking is already cancelled");
        }

        booking.setStatus("cancelled");
        bookingRepository.save(booking);

        emailService.sendCancellationEmail(booking.getContactEmail(), booking.getPnr());
    }

    private String generateUniquePnr() {
        String pnr;
        int attempts = 0;
        do {
            StringBuilder sb = new StringBuilder(6);
            for (int i = 0; i < 6; i++) {
                sb.append(PNR_CHARS.charAt(SECURE_RANDOM.nextInt(PNR_CHARS.length())));
            }
            pnr = sb.toString();
            attempts++;
            if (attempts > 20) {
                throw new IllegalStateException("Unable to generate a unique PNR after 20 attempts");
            }
        } while (bookingRepository.existsById(pnr));
        return pnr;
    }
}
