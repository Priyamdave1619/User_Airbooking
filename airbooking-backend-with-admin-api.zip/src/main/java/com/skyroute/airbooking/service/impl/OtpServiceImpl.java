package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.entity.OtpVerification;
import com.skyroute.airbooking.exception.TooManyRequestsException;
import com.skyroute.airbooking.mail.EmailService;
import com.skyroute.airbooking.repository.OtpVerificationRepository;
import com.skyroute.airbooking.service.OtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

/**
 * OTP lifecycle backed by the database. Codes are never stored in plaintext —
 * only a BCrypt hash — and every previous code for a target/purpose is
 * implicitly invalidated because verification always looks up the *latest*
 * record and expired/consumed records are never reused.
 */
@Service
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final OtpVerificationRepository otpRepository;
    private final EmailService emailService;

    @Value("${app.security.otp.ttl-seconds}")
    private long ttlSeconds;

    @Value("${app.security.otp.resend-cooldown-seconds}")
    private long resendCooldownSeconds;

    @Value("${app.security.otp.max-attempts}")
    private int maxAttempts;

    @Override
    @Transactional
    public void generateAndSend(String target, String purpose) {
        if (!canResend(target, purpose)) {
            throw new TooManyRequestsException("Please wait before requesting another code");
        }
        String code = generateSixDigitCode();
        OtpVerification record = OtpVerification.builder()
                .target(target)
                .purpose(purpose)
                .codeHash(BCrypt.hashpw(code, BCrypt.gensalt(10)))
                .attempts(0)
                .maxAttempts((int) maxAttempts)
                .verified(false)
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusSeconds(ttlSeconds))
                .build();
        otpRepository.save(record);
        emailService.sendOtpEmail(target, code, (int) (ttlSeconds / 60));
    }

    @Override
    public boolean canResend(String target, String purpose) {
        Optional<OtpVerification> last = otpRepository
                .findFirstByTargetAndPurposeOrderByCreatedAtDesc(target, purpose);
        return last.map(o -> ChronoUnit.SECONDS.between(o.getCreatedAt(), LocalDateTime.now()) >= resendCooldownSeconds)
                .orElse(true);
    }

    @Override
    @Transactional
    public VerifyResult verify(String target, String purpose, String code) {
        Optional<OtpVerification> maybeRecord =
                otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc(target, purpose);
        if (maybeRecord.isEmpty()) {
            return VerifyResult.NOT_FOUND;
        }
        OtpVerification record = maybeRecord.get();

        if (LocalDateTime.now().isAfter(record.getExpiresAt())) {
            return VerifyResult.EXPIRED;
        }
        if (record.getAttempts() >= record.getMaxAttempts()) {
            return VerifyResult.MAX_ATTEMPTS_EXCEEDED;
        }

        record.setAttempts(record.getAttempts() + 1);

        if (!BCrypt.checkpw(code, record.getCodeHash())) {
            otpRepository.save(record);
            return VerifyResult.INVALID;
        }

        record.setVerified(true);
        otpRepository.save(record);
        return VerifyResult.OK;
    }

    @Override
    public boolean isVerified(String target, String purpose) {
        return otpRepository.findFirstByTargetAndPurposeOrderByCreatedAtDesc(target, purpose)
                .map(OtpVerification::isVerified)
                .orElse(false);
    }

    /** Cryptographically secure 6-digit numeric OTP (100000-999999). */
    private String generateSixDigitCode() {
        int code = 100000 + SECURE_RANDOM.nextInt(900000);
        return String.valueOf(code);
    }
}
