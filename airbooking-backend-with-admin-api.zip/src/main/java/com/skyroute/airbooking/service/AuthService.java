package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.request.*;
import com.skyroute.airbooking.dto.response.AuthResponse;
import com.skyroute.airbooking.dto.response.UserResponse;

public interface AuthService {

    /** Registers the account (unverified) and dispatches a registration OTP. */
    void register(RegisterRequest request);

    /** Verifies the registration OTP and activates the account. */
    AuthResponse verifyRegistration(OtpVerifyRequest request, String deviceInfo, String ipAddress);

    AuthResponse login(LoginRequest request, String deviceInfo, String ipAddress);

    AuthResponse refresh(RefreshTokenRequest request, String deviceInfo, String ipAddress);

    void logout(String refreshToken);

    void logoutAllDevices(java.util.UUID userId);

    void forgotPassword(ForgotPasswordRequest request);

    void resetPassword(ResetPasswordRequest request);

    void changePassword(java.util.UUID userId, ChangePasswordRequest request);

    UserResponse getCurrentUser(java.util.UUID userId);
}
