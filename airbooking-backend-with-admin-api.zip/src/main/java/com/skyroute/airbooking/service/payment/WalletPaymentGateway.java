package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.exception.BadRequestException;
import org.springframework.stereotype.Component;

import java.security.SecureRandom;

@Component
public class WalletPaymentGateway implements PaymentGateway {

    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    public String getMethodCode() {
        return "wallet";
    }

    @Override
    public PaymentGatewayResult charge(ProcessPaymentRequest request) {
        if (request.walletProvider() == null || request.walletProvider().isBlank()) {
            throw new BadRequestException("A wallet provider must be selected");
        }
        boolean success = RANDOM.nextInt(100) < 98;
        if (!success) {
            return new PaymentGatewayResult(false, null, "Wallet: " + request.walletProvider(), "Insufficient wallet balance");
        }
        String referenceId = "WAL-" + System.currentTimeMillis() + "-" + RANDOM.nextInt(9999);
        return new PaymentGatewayResult(true, referenceId, "Wallet: " + request.walletProvider(), null);
    }
}
