package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.request.CreateBookingRequest;
import com.skyroute.airbooking.dto.response.BookingResponse;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

public interface BookingService {

    BookingResponse createBooking(CreateBookingRequest request, UUID userId);

    BookingResponse getByPnr(String pnr);

    org.springframework.data.domain.Page<BookingResponse> getMyBookings(UUID userId, Pageable pageable);

    void cancelBooking(String pnr, UUID userId);
}
