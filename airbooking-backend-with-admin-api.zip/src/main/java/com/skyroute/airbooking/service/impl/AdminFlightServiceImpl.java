package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.admin.AircraftRequest;
import com.skyroute.airbooking.dto.admin.AircraftResponse;
import com.skyroute.airbooking.dto.admin.CreateFlightRequest;
import com.skyroute.airbooking.dto.admin.FlightSegmentRequest;
import com.skyroute.airbooking.dto.admin.UpdateFlightRequest;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import com.skyroute.airbooking.entity.Aircraft;
import com.skyroute.airbooking.entity.City;
import com.skyroute.airbooking.entity.Flight;
import com.skyroute.airbooking.entity.FlightSegment;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.ConflictException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.mapper.FlightMapper;
import com.skyroute.airbooking.repository.AircraftRepository;
import com.skyroute.airbooking.repository.CityRepository;
import com.skyroute.airbooking.repository.FlightRepository;
import com.skyroute.airbooking.repository.SeatRepository;
import com.skyroute.airbooking.service.AdminFlightService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminFlightServiceImpl implements AdminFlightService {

    private final FlightRepository flightRepository;
    private final CityRepository cityRepository;
    private final AircraftRepository aircraftRepository;
    private final SeatRepository seatRepository;
    private final FlightMapper flightMapper;
    private final AdminSeatMapSeeder seatMapSeeder;

    @Override
    public Page<FlightOfferResponse> listFlights(Pageable pageable) {
        return flightRepository.findAllByOrderByDepartureDateDescIdAsc(pageable).map(flightMapper::toResponse);
    }

    @Override
    public FlightOfferResponse getFlight(String id) {
        return flightMapper.toResponse(findFlightOrThrow(id));
    }

    @Override
    @Transactional
    @CacheEvict(value = {"flightSearch", "cities"}, allEntries = true)
    public FlightOfferResponse createFlight(CreateFlightRequest request) {
        if (flightRepository.existsById(request.id())) {
            throw new ConflictException("A flight with id " + request.id() + " already exists");
        }

        City from = findCityOrThrow(request.fromCode());
        City to = findCityOrThrow(request.toCode());
        Aircraft aircraft = request.aircraftId() != null ? findAircraftOrThrow(request.aircraftId()) : null;

        Flight flight = Flight.builder()
                .id(request.id())
                .from(from)
                .to(to)
                .departTime(request.departTime())
                .arriveTime(request.arriveTime())
                .duration(request.duration())
                .stops(request.stops())
                .stopLabel(request.stopLabel())
                .travelClass(request.travelClass())
                .fareName(request.fareName())
                .priceInr(request.priceInr())
                .baggage(request.baggage())
                .handBaggage(request.handBaggage())
                .seatSelection(request.seatSelection())
                .upgradeToFirst(request.upgradeToFirst())
                .changeFee(request.changeFee())
                .refundFee(request.refundFee())
                .aircraft(aircraft)
                .departureDate(request.departureDate())
                .active(true)
                .build();

        applySegments(flight, request.segments());
        Flight saved = flightRepository.save(flight);

        seatRepository.saveAll(seatMapSeeder.buildSeatsFor(saved.getId()));

        return flightMapper.toResponse(saved);
    }

    @Override
    @Transactional
    @CacheEvict(value = {"flightSearch", "cities"}, allEntries = true)
    public FlightOfferResponse updateFlight(String id, UpdateFlightRequest request) {
        Flight flight = findFlightOrThrow(id);

        flight.setFrom(findCityOrThrow(request.fromCode()));
        flight.setTo(findCityOrThrow(request.toCode()));
        flight.setDepartTime(request.departTime());
        flight.setArriveTime(request.arriveTime());
        flight.setDuration(request.duration());
        flight.setStops(request.stops());
        flight.setStopLabel(request.stopLabel());
        flight.setTravelClass(request.travelClass());
        flight.setFareName(request.fareName());
        flight.setPriceInr(request.priceInr());
        flight.setBaggage(request.baggage());
        flight.setHandBaggage(request.handBaggage());
        flight.setSeatSelection(request.seatSelection());
        flight.setUpgradeToFirst(request.upgradeToFirst());
        flight.setChangeFee(request.changeFee());
        flight.setRefundFee(request.refundFee());
        flight.setAircraft(request.aircraftId() != null ? findAircraftOrThrow(request.aircraftId()) : null);
        flight.setDepartureDate(request.departureDate());
        flight.setActive(request.active());

        if (request.segments() != null && !request.segments().isEmpty()) {
            flight.getSegments().clear();
            applySegments(flight, request.segments());
        }

        return flightMapper.toResponse(flightRepository.save(flight));
    }

    @Override
    @Transactional
    @CacheEvict(value = {"flightSearch", "cities"}, allEntries = true)
    public FlightOfferResponse setActive(String id, boolean active) {
        Flight flight = findFlightOrThrow(id);
        flight.setActive(active);
        return flightMapper.toResponse(flightRepository.save(flight));
    }

    @Override
    public List<AircraftResponse> listAircraft() {
        return aircraftRepository.findAll().stream()
                .map(a -> new AircraftResponse(a.getId(), a.getModel(), a.getTotalSeats()))
                .toList();
    }

    @Override
    public AircraftResponse createAircraft(AircraftRequest request) {
        Aircraft saved = aircraftRepository.save(
                Aircraft.builder().model(request.model()).totalSeats(request.totalSeats()).build());
        return new AircraftResponse(saved.getId(), saved.getModel(), saved.getTotalSeats());
    }

    private void applySegments(Flight flight, List<FlightSegmentRequest> segments) {
        if (segments == null) return;
        int seq = 1;
        for (FlightSegmentRequest s : segments) {
            flight.getSegments().add(FlightSegment.builder()
                    .flight(flight)
                    .sequenceNo(seq++)
                    .airlineCode(s.airlineCode())
                    .flightNumber(s.flightNumber())
                    .aircraft(s.aircraft())
                    .build());
        }
    }

    private Flight findFlightOrThrow(String id) {
        return flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + id));
    }

    private City findCityOrThrow(String code) {
        return cityRepository.findById(code)
                .orElseThrow(() -> new BadRequestException("Unknown city code: " + code));
    }

    private Aircraft findAircraftOrThrow(Long id) {
        return aircraftRepository.findById(id)
                .orElseThrow(() -> new BadRequestException("Unknown aircraft id: " + id));
    }
}
