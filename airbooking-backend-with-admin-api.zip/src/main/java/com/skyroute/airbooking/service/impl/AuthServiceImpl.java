package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.request.*;
import com.skyroute.airbooking.dto.response.AuthResponse;
import com.skyroute.airbooking.dto.response.UserResponse;
import com.skyroute.airbooking.entity.RefreshToken;
import com.skyroute.airbooking.entity.Role;
import com.skyroute.airbooking.entity.User;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.ConflictException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.exception.UnauthorizedException;
import com.skyroute.airbooking.mail.EmailService;
import com.skyroute.airbooking.mapper.UserMapper;
import com.skyroute.airbooking.repository.RefreshTokenRepository;
import com.skyroute.airbooking.repository.RoleRepository;
import com.skyroute.airbooking.repository.UserRepository;
import com.skyroute.airbooking.security.JwtService;
import com.skyroute.airbooking.service.AuthService;
import com.skyroute.airbooking.service.OtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();
    private static final String OTP_PURPOSE_REGISTRATION = "registration";
    private static final String OTP_PURPOSE_PASSWORD_RESET = "password_reset";

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final OtpService otpService;
    private final EmailService emailService;
    private final UserMapper userMapper;

    @Value("${app.security.jwt.refresh-token-ttl-seconds}")
    private long refreshTokenTtlSeconds;

    @Override
    @Transactional
    public void register(RegisterRequest request) {
        if (userRepository.existsByEmailAndDeletedFalse(request.email())) {
            throw new ConflictException("An account with this email already exists");
        }
        Role userRole = roleRepository.findByName("ROLE_USER")
                .orElseThrow(() -> new IllegalStateException("Default ROLE_USER is not seeded"));

        User user = User.builder()
                .firstName(request.firstName())
                .lastName(request.lastName())
                .email(request.email().toLowerCase())
                .phone(request.phone())
                .passwordHash(passwordEncoder.encode(request.password()))
                .emailVerified(false)
                .roles(Set.of(userRole))
                .build();
        userRepository.save(user);

        otpService.generateAndSend(user.getEmail(), OTP_PURPOSE_REGISTRATION);
    }

    @Override
    @Transactional
    public AuthResponse verifyRegistration(OtpVerifyRequest request, String deviceInfo, String ipAddress) {
        OtpService.VerifyResult result = otpService.verify(
                request.target(), OTP_PURPOSE_REGISTRATION, request.code());
        validateOtpResult(result);

        User user = userRepository.findByEmailAndDeletedFalse(request.target())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        user.setEmailVerified(true);
        userRepository.save(user);

        emailService.sendWelcomeEmail(user.getEmail(), user.getFirstName());

        return issueTokens(user, deviceInfo, ipAddress);
    }

    @Override
    @Transactional
    public AuthResponse login(LoginRequest request, String deviceInfo, String ipAddress) {
        User user = userRepository.findByEmailAndDeletedFalse(request.email().toLowerCase())
                .orElseThrow(() -> new UnauthorizedException("Invalid email or password"));

        if (user.isAccountLocked() && user.getAccountLockedUntil() != null
                && user.getAccountLockedUntil().isAfter(LocalDateTime.now())) {
            throw new UnauthorizedException("Account temporarily locked due to repeated failed attempts");
        }

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            registerFailedAttempt(user);
            throw new UnauthorizedException("Invalid email or password");
        }

        if (!user.isEmailVerified()) {
            throw new UnauthorizedException("Please verify your email before logging in");
        }

        user.setFailedLoginCount(0);
        user.setAccountLocked(false);
        user.setAccountLockedUntil(null);
        userRepository.save(user);

        return issueTokens(user, deviceInfo, ipAddress);
    }

    @Override
    @Transactional
    public AuthResponse refresh(RefreshTokenRequest request, String deviceInfo, String ipAddress) {
        String incomingHash = hashToken(request.refreshToken());
        RefreshToken existing = refreshTokenRepository.findByTokenHash(incomingHash)
                .orElseThrow(() -> new UnauthorizedException("Invalid or expired refresh token"));

        if (existing.isRevoked() || existing.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new UnauthorizedException("Invalid or expired refresh token");
        }

        // Rotate: revoke the presented token and issue a brand-new pair.
        existing.setRevoked(true);
        existing.setRevokedAt(LocalDateTime.now());
        refreshTokenRepository.save(existing);

        User user = existing.getUser();
        return issueTokens(user, deviceInfo, ipAddress);
    }

    @Override
    @Transactional
    public void logout(String refreshToken) {
        String hash = hashToken(refreshToken);
        refreshTokenRepository.findByTokenHash(hash).ifPresent(token -> {
            token.setRevoked(true);
            token.setRevokedAt(LocalDateTime.now());
            refreshTokenRepository.save(token);
        });
    }

    @Override
    @Transactional
    public void logoutAllDevices(UUID userId) {
        refreshTokenRepository.revokeAllForUser(userId);
    }

    @Override
    @Transactional
    public void forgotPassword(ForgotPasswordRequest request) {
        // Always behave the same whether or not the account exists, to avoid user enumeration.
        userRepository.findByEmailAndDeletedFalse(request.email().toLowerCase())
                .ifPresent(user -> otpService.generateAndSend(user.getEmail(), OTP_PURPOSE_PASSWORD_RESET));
    }

    @Override
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        OtpService.VerifyResult result = otpService.verify(
                request.email().toLowerCase(), OTP_PURPOSE_PASSWORD_RESET, request.otpCode());
        validateOtpResult(result);

        User user = userRepository.findByEmailAndDeletedFalse(request.email().toLowerCase())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        user.setPasswordHash(passwordEncoder.encode(request.newPassword()));
        userRepository.save(user);
        refreshTokenRepository.revokeAllForUser(user.getId());
    }

    @Override
    @Transactional
    public void changePassword(UUID userId, ChangePasswordRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        if (!passwordEncoder.matches(request.currentPassword(), user.getPasswordHash())) {
            throw new BadRequestException("Current password is incorrect");
        }
        user.setPasswordHash(passwordEncoder.encode(request.newPassword()));
        userRepository.save(user);
    }

    @Override
    public UserResponse getCurrentUser(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        return userMapper.toResponse(user);
    }

    private void validateOtpResult(OtpService.VerifyResult result) {
        switch (result) {
            case OK -> { /* proceed */ }
            case EXPIRED -> throw new BadRequestException("This code has expired. Please request a new one.");
            case INVALID -> throw new BadRequestException("Incorrect verification code.");
            case MAX_ATTEMPTS_EXCEEDED -> throw new BadRequestException("Too many incorrect attempts. Please request a new code.");
            case NOT_FOUND -> throw new BadRequestException("No verification code found for this request.");
        }
    }

    private void registerFailedAttempt(User user) {
        user.setFailedLoginCount(user.getFailedLoginCount() + 1);
        if (user.getFailedLoginCount() >= 5) {
            user.setAccountLocked(true);
            user.setAccountLockedUntil(LocalDateTime.now().plusMinutes(15));
        }
        userRepository.save(user);
    }

    private AuthResponse issueTokens(User user, String deviceInfo, String ipAddress) {
        List<String> roles = user.getRoles().stream().map(Role::getName).toList();
        String accessToken = jwtService.generateAccessToken(user.getId(), user.getEmail(), roles);

        String rawRefreshToken = generateOpaqueToken();
        RefreshToken refreshToken = RefreshToken.builder()
                .user(user)
                .tokenHash(hashToken(rawRefreshToken))
                .deviceInfo(deviceInfo)
                .ipAddress(ipAddress)
                .issuedAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusSeconds(refreshTokenTtlSeconds))
                .revoked(false)
                .build();
        refreshTokenRepository.save(refreshToken);

        return new AuthResponse(
                accessToken,
                rawRefreshToken,
                jwtService.getAccessTokenTtlSeconds(),
                userMapper.toResponse(user));
    }

    private String generateOpaqueToken() {
        byte[] bytes = new byte[48];
        SECURE_RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    /**
     * Refresh tokens are hashed at rest so a DB leak doesn't expose usable session tokens.
     * SHA-256 (rather than BCrypt) is used deliberately: the token itself is a 384-bit
     * cryptographically random value (not a low-entropy password), so a slow, salted KDF
     * provides no additional protection here but would prevent the deterministic lookup
     * required to find a token record by its presented value.
     */
    private String hashToken(String rawToken) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(rawToken.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm unavailable", e);
        }
    }
}
