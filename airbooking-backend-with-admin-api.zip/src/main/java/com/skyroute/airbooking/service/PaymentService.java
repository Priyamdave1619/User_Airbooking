package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;
import com.skyroute.airbooking.dto.response.TransactionResponse;

import java.util.List;
import java.util.UUID;

public interface PaymentService {

    TransactionResponse processPayment(ProcessPaymentRequest request);

    List<TransactionResponse> getBookingTransactions(String pnr);

    List<TransactionResponse> getMyTransactionHistory(UUID userId);
}
