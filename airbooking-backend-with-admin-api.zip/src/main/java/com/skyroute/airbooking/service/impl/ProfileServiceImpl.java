package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.request.UpdateProfileRequest;
import com.skyroute.airbooking.dto.response.UserResponse;
import com.skyroute.airbooking.entity.User;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.mapper.UserMapper;
import com.skyroute.airbooking.repository.UserRepository;
import com.skyroute.airbooking.service.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProfileServiceImpl implements ProfileService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;

    @Override
    @Transactional
    public UserResponse updateProfile(UUID userId, UpdateProfileRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));

        if (StringUtils.hasText(request.firstName())) user.setFirstName(request.firstName());
        if (request.lastName() != null) user.setLastName(request.lastName());
        if (request.phone() != null) user.setPhone(request.phone());
        if (request.gender() != null) user.setGender(request.gender());
        if (StringUtils.hasText(request.dateOfBirth())) user.setDateOfBirth(LocalDate.parse(request.dateOfBirth()));
        if (request.nationality() != null) user.setNationality(request.nationality());
        if (request.passportNumber() != null) user.setPassportNumber(request.passportNumber());
        if (StringUtils.hasText(request.passportExpiry())) user.setPassportExpiry(LocalDate.parse(request.passportExpiry()));
        if (request.passportCountry() != null) user.setPassportCountry(request.passportCountry());
        if (request.addressLine1() != null) user.setAddressLine1(request.addressLine1());
        if (request.addressLine2() != null) user.setAddressLine2(request.addressLine2());
        if (request.city() != null) user.setCity(request.city());
        if (request.state() != null) user.setState(request.state());
        if (request.postalCode() != null) user.setPostalCode(request.postalCode());
        if (request.country() != null) user.setCountry(request.country());

        userRepository.save(user);
        return userMapper.toResponse(user);
    }

    @Override
    @Transactional
    public UserResponse updateAvatar(UUID userId, String avatarUrl) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found"));
        user.setAvatarUrl(avatarUrl);
        userRepository.save(user);
        return userMapper.toResponse(user);
    }
}
