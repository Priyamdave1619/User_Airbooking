package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.response.CityResponse;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;

import java.time.LocalDate;
import java.util.List;

public interface FlightService {

    List<CityResponse> getAllCities();

    List<FlightOfferResponse> search(String fromCode, String toCode, LocalDate date, String travelClass);

    FlightOfferResponse getById(String flightId);
}
