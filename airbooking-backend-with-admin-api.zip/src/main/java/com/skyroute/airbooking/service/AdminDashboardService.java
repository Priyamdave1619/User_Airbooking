package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.admin.AdminDashboardStatsResponse;

public interface AdminDashboardService {
    AdminDashboardStatsResponse getStats();
}
