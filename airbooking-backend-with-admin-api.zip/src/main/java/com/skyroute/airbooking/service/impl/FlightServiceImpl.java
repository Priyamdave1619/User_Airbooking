package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.response.CityResponse;
import com.skyroute.airbooking.dto.response.FlightOfferResponse;
import com.skyroute.airbooking.entity.Flight;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.mapper.FlightMapper;
import com.skyroute.airbooking.repository.CityRepository;
import com.skyroute.airbooking.repository.FlightRepository;
import com.skyroute.airbooking.service.FlightService;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;
    private final CityRepository cityRepository;
    private final FlightMapper flightMapper;

    @Override
    @Cacheable(value = "cities", unless = "#result.isEmpty()")
    public List<CityResponse> getAllCities() {
        return cityRepository.findAll().stream().map(flightMapper::toResponse).toList();
    }

    @Override
    @Cacheable(value = "flightSearch", key = "#fromCode + '-' + #toCode + '-' + #date + '-' + #travelClass")
    public List<FlightOfferResponse> search(String fromCode, String toCode, LocalDate date, String travelClass) {
        List<Flight> flights = flightRepository.search(fromCode, toCode, date);
        return flights.stream()
                .filter(f -> travelClass == null || travelClass.isBlank() || f.getTravelClass().equalsIgnoreCase(travelClass))
                .map(flightMapper::toResponse)
                .toList();
    }

    @Override
    public FlightOfferResponse getById(String flightId) {
        Flight flight = flightRepository.findByIdAndActiveTrue(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found: " + flightId));
        return flightMapper.toResponse(flight);
    }
}
