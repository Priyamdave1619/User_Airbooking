package com.skyroute.airbooking.service.payment;

import com.skyroute.airbooking.dto.request.ProcessPaymentRequest;

/**
 * Abstraction over a payment method. Concrete implementations are mock
 * gateways today; swapping in Stripe/Razorpay/PayPal means implementing
 * this interface and registering it in {@link PaymentGatewayFactory} —
 * no changes needed anywhere else in the booking/payment flow.
 */
public interface PaymentGateway {

    String getMethodCode(); // card, upi, netbanking, wallet

    PaymentGatewayResult charge(ProcessPaymentRequest request);

    record PaymentGatewayResult(boolean success, String referenceId, String methodLabel, String failureReason) {
    }
}
