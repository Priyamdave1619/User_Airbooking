package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.request.CheckInRequest;
import com.skyroute.airbooking.dto.request.SeatChangeRequest;
import com.skyroute.airbooking.dto.response.BoardingPassResponse;
import com.skyroute.airbooking.dto.response.BookingResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.entity.BookingPassenger;
import com.skyroute.airbooking.entity.Seat;
import com.skyroute.airbooking.exception.BadRequestException;
import com.skyroute.airbooking.exception.ResourceNotFoundException;
import com.skyroute.airbooking.exception.SeatUnavailableException;
import com.skyroute.airbooking.mapper.BookingMapper;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.repository.SeatRepository;
import com.skyroute.airbooking.service.CheckInService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CheckInServiceImpl implements CheckInService {

    private final BookingRepository bookingRepository;
    private final SeatRepository seatRepository;
    private final BookingMapper bookingMapper;

    @Override
    public BookingResponse lookup(CheckInRequest request) {
        Booking booking = findBooking(request.pnr(), request.contactEmail());
        return bookingMapper.toResponse(booking);
    }

    @Override
    @Transactional
    public List<BoardingPassResponse> checkIn(CheckInRequest request) {
        Booking booking = findBooking(request.pnr(), request.contactEmail());

        if (!"confirmed".equals(booking.getStatus()) && !"checked_in".equals(booking.getStatus())) {
            throw new BadRequestException("This booking must be confirmed (paid) before check-in");
        }

        int seq = 1;
        for (BookingPassenger p : booking.getPassengers()) {
            if (p.getSeatId() == null) {
                throw new BadRequestException("Passenger " + p.getFullName() + " has no assigned seat. Please select a seat first.");
            }
            p.setCheckedIn(true);
            p.setBoardingSeq(seq++);
        }
        booking.setStatus("checked_in");
        bookingRepository.save(booking);

        return buildBoardingPasses(booking);
    }

    @Override
    @Transactional
    public BoardingPassResponse changeSeat(SeatChangeRequest request) {
        Booking booking = bookingRepository.findByPnrAndDeletedFalse(request.pnr())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for PNR: " + request.pnr()));

        BookingPassenger passenger = booking.getPassengers().stream()
                .filter(p -> p.getId().toString().equals(request.passengerId()))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Passenger not found on this booking"));

        Seat newSeat = seatRepository.findById(new Seat.SeatId(request.newSeatId(), booking.getFlight().getId()))
                .orElseThrow(() -> new BadRequestException("Seat " + request.newSeatId() + " does not exist on this flight"));

        boolean seatTaken = booking.getPassengers().stream()
                .anyMatch(p -> !p.getId().equals(passenger.getId()) && request.newSeatId().equals(p.getSeatId()));
        List<Booking> otherActive = bookingRepository.findByFlight_IdAndStatusNot(booking.getFlight().getId(), "cancelled");
        boolean seatTakenElsewhere = otherActive.stream()
                .filter(b -> !b.getPnr().equals(booking.getPnr()))
                .flatMap(b -> b.getPassengers().stream())
                .anyMatch(p -> request.newSeatId().equals(p.getSeatId()));

        if (seatTaken || seatTakenElsewhere) {
            throw new SeatUnavailableException("Seat " + request.newSeatId() + " is already taken");
        }

        passenger.setSeatId(request.newSeatId());
        bookingRepository.save(booking);

        return toBoardingPass(booking, passenger, newSeat.getRowNo() + newSeat.getColLetter(),
                passenger.getBoardingSeq() != null ? passenger.getBoardingSeq() : 1);
    }

    private List<BoardingPassResponse> buildBoardingPasses(Booking booking) {
        Map<String, Seat> seatsById = seatRepository.findByFlightIdOrderByRowNoAscColLetterAsc(booking.getFlight().getId())
                .stream().collect(java.util.stream.Collectors.toMap(Seat::getId, s -> s));

        return booking.getPassengers().stream().map(p -> {
            Seat seat = seatsById.get(p.getSeatId());
            String seatLabel = seat != null ? seat.getRowNo() + seat.getColLetter() : p.getSeatId();
            return toBoardingPass(booking, p, seatLabel, p.getBoardingSeq() != null ? p.getBoardingSeq() : 1);
        }).toList();
    }

    private BoardingPassResponse toBoardingPass(Booking booking, BookingPassenger p, String seatLabel, int seq) {
        return new BoardingPassResponse(
                booking.getPnr(),
                p.getFullName(),
                booking.getFlight().getId(),
                booking.getFlight().getFrom().getCode(),
                booking.getFlight().getTo().getCode(),
                seatLabel,
                booking.getFlight().getTravelClass(),
                "TBD", // gate assignment is typically finalized closer to departure
                subtractMinutes(booking.getFlight().getDepartTime(), 45),
                booking.getFlight().getDepartTime(),
                seq
        );
    }

    private String subtractMinutes(String hhmm, int minutes) {
        try {
            String[] parts = hhmm.split(":");
            int total = Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]) - minutes;
            total = ((total % 1440) + 1440) % 1440;
            return String.format("%02d:%02d", total / 60, total % 60);
        } catch (Exception e) {
            return hhmm;
        }
    }

    private Booking findBooking(String pnr, String contactEmail) {
        return bookingRepository.findByPnrAndContactEmailIgnoreCaseAndDeletedFalse(pnr, contactEmail)
                .orElseThrow(() -> new ResourceNotFoundException("No booking found matching that PNR and email"));
    }
}
