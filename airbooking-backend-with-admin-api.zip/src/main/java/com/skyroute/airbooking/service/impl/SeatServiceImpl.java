package com.skyroute.airbooking.service.impl;

import com.skyroute.airbooking.dto.response.SeatLockResponse;
import com.skyroute.airbooking.dto.response.SeatResponse;
import com.skyroute.airbooking.entity.Booking;
import com.skyroute.airbooking.entity.Seat;
import com.skyroute.airbooking.exception.SeatUnavailableException;
import com.skyroute.airbooking.repository.BookingRepository;
import com.skyroute.airbooking.repository.SeatRepository;
import com.skyroute.airbooking.service.SeatService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Seat holds are stored in Redis with a TTL matching the frontend's 5-minute
 * lock semantics (src/lib/store/db.ts SEAT_LOCK_TTL_MS). Redis' native
 * expiry replaces the frontend's manual "now - lockedAt < TTL" filtering,
 * and works correctly across multiple app instances (unlike the browser's
 * localStorage simulation).
 */
@Service
@RequiredArgsConstructor
public class SeatServiceImpl implements SeatService {

    private static final String LOCK_KEY_PREFIX = "seat_lock:";

    private final SeatRepository seatRepository;
    private final BookingRepository bookingRepository;
    private final RedisTemplate<String, Object> redisTemplate;

    @Value("${app.security.seat-lock.ttl-seconds}")
    private long lockTtlSeconds;

    @Override
    public List<SeatResponse> getSeatMap(String flightId, String requestingSessionId) {
        List<Seat> seats = seatRepository.findByFlightIdOrderByRowNoAscColLetterAsc(flightId);
        Set<String> occupied = getOccupiedSeatIds(flightId);

        return seats.stream().map(seat -> {
            String lockKey = lockKey(flightId, seat.getId());
            SeatLockRecord lock = (SeatLockRecord) redisTemplate.opsForValue().get(lockKey);

            String status;
            Long lockedAt = null;
            String lockedBy = null;

            if (occupied.contains(seat.getId())) {
                status = "occupied";
            } else if (lock != null) {
                status = lock.getLockedBy().equals(requestingSessionId) ? "selected" : "locked";
                lockedAt = lock.getLockedAtEpochMs();
                lockedBy = lock.getLockedBy();
            } else {
                status = "available";
            }

            return new SeatResponse(
                    seat.getId(), seat.getRowNo(), seat.getColLetter(),
                    seat.getRowNo() + seat.getColLetter(), seat.getTier(), seat.getPriceInr(),
                    seat.isExitRow(), seat.isWindow(), seat.isAisle(),
                    status, lockedAt, lockedBy
            );
        }).toList();
    }

    @Override
    public SeatLockResponse lockSeat(String flightId, String seatId, String sessionId) {
        Set<String> occupied = getOccupiedSeatIds(flightId);
        if (occupied.contains(seatId)) {
            throw new SeatUnavailableException("Seat " + seatId + " is already booked");
        }

        String lockKey = lockKey(flightId, seatId);
        SeatLockRecord existing = (SeatLockRecord) redisTemplate.opsForValue().get(lockKey);
        if (existing != null && !existing.getLockedBy().equals(sessionId)) {
            throw new SeatUnavailableException("Seat " + seatId + " is currently held by another passenger");
        }

        long now = Instant.now().toEpochMilli();
        SeatLockRecord record = new SeatLockRecord(flightId, seatId, sessionId, now);
        redisTemplate.opsForValue().set(lockKey, record, Duration.ofSeconds(lockTtlSeconds));

        return new SeatLockResponse(flightId, seatId, sessionId, now, lockTtlSeconds);
    }

    @Override
    public void releaseSeat(String flightId, String seatId, String sessionId) {
        String lockKey = lockKey(flightId, seatId);
        SeatLockRecord existing = (SeatLockRecord) redisTemplate.opsForValue().get(lockKey);
        if (existing != null && existing.getLockedBy().equals(sessionId)) {
            redisTemplate.delete(lockKey);
        }
    }

    @Override
    public void releaseAllSeatsForSession(String flightId, String sessionId) {
        List<Seat> seats = seatRepository.findByFlightIdOrderByRowNoAscColLetterAsc(flightId);
        for (Seat seat : seats) {
            releaseSeat(flightId, seat.getId(), sessionId);
        }
    }

    /** Permanently marks seats as occupied once a booking is confirmed (called by BookingService). */
    public void clearLocksForSeats(String flightId, List<String> seatIds) {
        for (String seatId : seatIds) {
            redisTemplate.delete(lockKey(flightId, seatId));
        }
    }

    private Set<String> getOccupiedSeatIds(String flightId) {
        List<Booking> bookings = bookingRepository.findByFlight_IdAndStatusNot(flightId, "cancelled");
        Set<String> occupied = new HashSet<>();
        for (Booking booking : bookings) {
            booking.getPassengers().forEach(p -> {
                if (p.getSeatId() != null) occupied.add(p.getSeatId());
            });
        }
        return occupied;
    }

    private String lockKey(String flightId, String seatId) {
        return LOCK_KEY_PREFIX + flightId + ":" + seatId;
    }
}
