package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.response.NotificationResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

public interface NotificationService {
    Page<NotificationResponse> getMyNotifications(UUID userId, Pageable pageable);
    void markAsRead(Long notificationId, UUID userId);
    void notify(UUID userId, String title, String message, String type);
}
