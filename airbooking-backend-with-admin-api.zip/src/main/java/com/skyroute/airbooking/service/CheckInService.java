package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.request.CheckInRequest;
import com.skyroute.airbooking.dto.request.SeatChangeRequest;
import com.skyroute.airbooking.dto.response.BoardingPassResponse;
import com.skyroute.airbooking.dto.response.BookingResponse;

import java.util.List;

public interface CheckInService {

    /** Looks up a booking by PNR + contact email, for the check-in lookup form. */
    BookingResponse lookup(CheckInRequest request);

    List<BoardingPassResponse> checkIn(CheckInRequest request);

    BoardingPassResponse changeSeat(SeatChangeRequest request);
}
