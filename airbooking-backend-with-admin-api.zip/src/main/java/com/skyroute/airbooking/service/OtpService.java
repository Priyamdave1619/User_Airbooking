package com.skyroute.airbooking.service;

public interface OtpService {

    /** Generates a new OTP, invalidates any previous one for this target/purpose, and emails it. */
    void generateAndSend(String target, String purpose);

    /** @return true if a resend is currently allowed (cooldown elapsed). */
    boolean canResend(String target, String purpose);

    enum VerifyResult { OK, EXPIRED, INVALID, MAX_ATTEMPTS_EXCEEDED, NOT_FOUND }

    VerifyResult verify(String target, String purpose, String code);

    boolean isVerified(String target, String purpose);
}
