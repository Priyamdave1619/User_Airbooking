package com.skyroute.airbooking.service;

import com.skyroute.airbooking.dto.request.UpdateProfileRequest;
import com.skyroute.airbooking.dto.response.UserResponse;

import java.util.UUID;

public interface ProfileService {
    UserResponse updateProfile(UUID userId, UpdateProfileRequest request);
    UserResponse updateAvatar(UUID userId, String avatarUrl);
}
