package com.skyroute.airbooking.common;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;

/**
 * Consistent response envelope for every API endpoint:
 * { success, message, timestamp, data, errors, traceId }
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiResponse<T>(
        boolean success,
        String message,
        Instant timestamp,
        T data,
        List<String> errors,
        String traceId
) {

    public static <T> ApiResponse<T> success(String message, T data) {
        return new ApiResponse<>(true, message, Instant.now(), data, null, TraceIdHolder.get());
    }

    public static <T> ApiResponse<T> success(String message) {
        return new ApiResponse<>(true, message, Instant.now(), null, null, TraceIdHolder.get());
    }

    public static <T> ApiResponse<T> failure(String message, List<String> errors) {
        return new ApiResponse<>(false, message, Instant.now(), null, errors, TraceIdHolder.get());
    }
}
