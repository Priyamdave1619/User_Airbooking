package com.skyroute.airbooking.common;

/**
 * Thread-local holder for the current request's correlation/trace ID,
 * set by {@link com.skyroute.airbooking.config.TraceIdFilter}.
 */
public final class TraceIdHolder {

    private static final ThreadLocal<String> CURRENT = new ThreadLocal<>();

    private TraceIdHolder() {
    }

    public static void set(String traceId) {
        CURRENT.set(traceId);
    }

    public static String get() {
        return CURRENT.get();
    }

    public static void clear() {
        CURRENT.remove();
    }
}
