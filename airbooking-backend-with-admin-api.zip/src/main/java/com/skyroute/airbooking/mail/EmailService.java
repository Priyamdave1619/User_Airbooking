package com.skyroute.airbooking.mail;

import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Sends transactional HTML emails asynchronously so request threads never
 * block on SMTP latency. Never logs credentials or full message bodies.
 */
@Service
@RequiredArgsConstructor
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;

    @Value("${app.mail.from}")
    private String fromAddress;

    @Value("${app.mail.from-name}")
    private String fromName;

    @Async("mailTaskExecutor")
    public void sendOtpEmail(String to, String otpCode, int ttlMinutes) {
        send(to, "Your SkyRoute verification code", "otp-email.html", Map.of(
                "otpCode", otpCode,
                "ttlMinutes", String.valueOf(ttlMinutes)));
    }

    @Async("mailTaskExecutor")
    public void sendBookingConfirmationEmail(String to, String pnr, String flightId, String fromCode,
                                              String toCode, String totalAmount) {
        send(to, "Booking Confirmed - PNR " + pnr, "booking-confirmation-email.html", Map.of(
                "pnr", pnr, "flightId", flightId, "fromCode", fromCode, "toCode", toCode,
                "totalAmount", totalAmount));
    }

    @Async("mailTaskExecutor")
    public void sendCancellationEmail(String to, String pnr) {
        send(to, "Booking Cancelled - PNR " + pnr, "cancellation-email.html", Map.of("pnr", pnr));
    }

    @Async("mailTaskExecutor")
    public void sendWelcomeEmail(String to, String firstName) {
        send(to, "Welcome to SkyRoute Airlines", "welcome-email.html", Map.of("firstName", firstName));
    }

    private void send(String to, String subject, String templateFile, Map<String, String> tokens) {
        try {
            String html = loadTemplate(templateFile, tokens);
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, StandardCharsets.UTF_8.name());
            helper.setTo(to);
            helper.setFrom(fromAddress, fromName);
            helper.setSubject(subject);
            helper.setText(html, true);
            mailSender.send(message);
        } catch (Exception ex) {
            // Never rethrow into the caller's transaction; email delivery is best-effort
            // and failures must not roll back bookings/registrations. Never log secrets.
            log.error("Failed to send email (template={}): {}", templateFile, ex.getMessage());
        }
    }

    private String loadTemplate(String templateFile, Map<String, String> tokens) throws IOException {
        ClassPathResource resource = new ClassPathResource("templates/" + templateFile);
        String content;
        try (InputStream is = resource.getInputStream()) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            is.transferTo(buffer);
            content = buffer.toString(StandardCharsets.UTF_8);
        }
        for (Map.Entry<String, String> entry : tokens.entrySet()) {
            content = content.replace("{{" + entry.getKey() + "}}", escape(entry.getValue()));
        }
        return content;
    }

    private String escape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
