package com.skyroute.airbooking.exception;

import org.springframework.http.HttpStatus;

public class SeatUnavailableException extends ApiException {
    public SeatUnavailableException(String message) {
        super(HttpStatus.CONFLICT, "SEAT_UNAVAILABLE", message);
    }
}
