package com.skyroute.airbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "seats")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@IdClass(Seat.SeatId.class)
public class Seat {

    @Id
    @Column(length = 20)
    private String id;

    @Id
    @Column(name = "flight_id", length = 30)
    private String flightId;

    @Column(name = "row_no", nullable = false)
    private int rowNo;

    @Column(name = "col_letter", nullable = false, length = 2)
    private String colLetter;

    @Column(nullable = false, length = 20)
    private String tier;

    @Column(name = "price_inr", nullable = false, precision = 10, scale = 2)
    private BigDecimal priceInr;

    @Column(name = "is_exit_row", nullable = false)
    private boolean exitRow;

    @Column(name = "is_window", nullable = false)
    private boolean window;

    @Column(name = "is_aisle", nullable = false)
    private boolean aisle;

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class SeatId implements Serializable {
        private String id;
        private String flightId;
    }
}
