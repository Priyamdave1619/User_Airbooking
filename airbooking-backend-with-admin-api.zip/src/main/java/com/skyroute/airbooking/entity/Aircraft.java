package com.skyroute.airbooking.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "aircraft")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Aircraft {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String model;

    @Column(name = "total_seats", nullable = false)
    private int totalSeats;
}
