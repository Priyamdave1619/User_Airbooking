package com.skyroute.airbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "booking_passengers")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BookingPassenger {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "booking_pnr", nullable = false)
    private Booking booking;

    @Column(name = "full_name", nullable = false, length = 150)
    private String fullName;

    private String phone;
    private String email;

    @Column(length = 5)
    private String age;

    @Column(length = 30)
    private String gender;

    @Column(name = "senior_citizen", nullable = false)
    @Builder.Default
    private boolean seniorCitizen = false;

    @Column(name = "seat_id", length = 20)
    private String seatId;

    @Column(name = "checked_in", nullable = false)
    @Builder.Default
    private boolean checkedIn = false;

    @Column(name = "boarding_seq")
    private Integer boardingSeq;
}
