package com.skyroute.airbooking.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "flights")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Flight {

    @Id
    @Column(length = 30)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "from_code", nullable = false)
    private City from;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "to_code", nullable = false)
    private City to;

    @Column(name = "depart_time", nullable = false, length = 10)
    private String departTime;

    @Column(name = "arrive_time", nullable = false, length = 10)
    private String arriveTime;

    @Column(nullable = false, length = 30)
    private String duration;

    @Column(nullable = false)
    private int stops;

    @Column(name = "stop_label")
    private String stopLabel;

    @Column(name = "travel_class", nullable = false, length = 30)
    private String travelClass;

    @Column(name = "fare_name")
    private String fareName;

    @Column(name = "price_inr", nullable = false, precision = 12, scale = 2)
    private BigDecimal priceInr;

    private String baggage;

    @Column(name = "hand_baggage")
    private String handBaggage;

    @Column(name = "seat_selection")
    private String seatSelection;

    @Column(name = "upgrade_to_first")
    private String upgradeToFirst;

    @Column(name = "change_fee")
    private String changeFee;

    @Column(name = "refund_fee")
    private String refundFee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "aircraft_id")
    private Aircraft aircraft;

    @Column(name = "departure_date", nullable = false)
    private LocalDate departureDate;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "flight", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("sequenceNo ASC")
    @Builder.Default
    private List<FlightSegment> segments = new ArrayList<>();
}
