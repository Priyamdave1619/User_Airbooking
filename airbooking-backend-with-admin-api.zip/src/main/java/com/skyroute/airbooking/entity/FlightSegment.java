package com.skyroute.airbooking.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "flight_segments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class FlightSegment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    @Column(name = "sequence_no", nullable = false)
    private int sequenceNo;

    @Column(name = "airline_code", nullable = false, length = 10)
    private String airlineCode;

    @Column(name = "flight_number", nullable = false, length = 20)
    private String flightNumber;

    private String aircraft;
}
