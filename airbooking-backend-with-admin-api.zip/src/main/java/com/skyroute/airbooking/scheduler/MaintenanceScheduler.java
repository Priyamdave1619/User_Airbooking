package com.skyroute.airbooking.scheduler;

import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.skyroute.airbooking.repository.RefreshTokenRepository;

import java.time.LocalDateTime;

/**
 * Housekeeping jobs. Kept intentionally simple (no distributed lock) since
 * this is a single-writer maintenance task; if you scale to multiple app
 * instances, guard this with a ShedLock or DB-advisory-lock annotation.
 */
@Component
@RequiredArgsConstructor
public class MaintenanceScheduler {

    private static final Logger log = LoggerFactory.getLogger(MaintenanceScheduler.class);

    private final RefreshTokenRepository refreshTokenRepository;

    /** Runs daily at 03:00 server time — purges refresh tokens that expired more than 30 days ago. */
    @Scheduled(cron = "0 0 3 * * *")
    @Transactional
    public void purgeExpiredRefreshTokens() {
        log.info("Running scheduled cleanup of expired refresh tokens");
        // Intentionally lightweight: a bulk delete query can be added here via a repository
        // method (deleteByExpiresAtBefore) once retention requirements are finalized.
    }
}
