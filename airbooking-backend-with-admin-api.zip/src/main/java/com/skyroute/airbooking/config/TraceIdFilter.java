package com.skyroute.airbooking.config;

import com.skyroute.airbooking.common.TraceIdHolder;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Assigns (or propagates) a correlation ID for every incoming request so
 * logs and API responses can be tied together end-to-end.
 */
@Component
@Order(1)
public class TraceIdFilter extends OncePerRequestFilter {

    private static final String HEADER_NAME = "X-Trace-Id";
    private static final String MDC_KEY = "traceId";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String incoming = request.getHeader(HEADER_NAME);
        String traceId = (incoming != null && !incoming.isBlank()) ? incoming : UUID.randomUUID().toString();
        try {
            TraceIdHolder.set(traceId);
            MDC.put(MDC_KEY, traceId);
            response.setHeader(HEADER_NAME, traceId);
            chain.doFilter(request, response);
        } finally {
            TraceIdHolder.clear();
            MDC.remove(MDC_KEY);
        }
    }
}
