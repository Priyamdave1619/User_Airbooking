# SkyRoute Admin

A standalone admin console for SkyRoute Airlines — manage flights, bookings,
payments, and users. Talks to the same Spring Boot backend as the main
booking site, using its new `/api/v1/admin/**` endpoints (also included in
this delivery — see `airbooking-backend-with-admin-api.zip`).

## 1. Run the backend

Use the updated backend project (`airbooking-backend-with-admin-api.zip`),
which adds the admin API this app needs. From its root:

```bash
docker-compose up
# or: ./mvnw spring-boot:run
```

## 2. Create your first admin user

There's no seeded admin account. Register a normal account through the
regular booking site (or `POST /api/v1/auth/register` + verify OTP), then
grant it the admin role directly in the database:

```sql
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u, roles r
WHERE u.email = 'you@example.com' AND r.name = 'ROLE_ADMIN';
```

You can also promote further users from inside this admin app itself once
you have one admin account (Users → "Make admin").

## 3. Configure & run this app

```bash
cp .env.local.example .env.local   # point at your backend if not localhost:8080
npm install
npm run dev
```

Open http://localhost:3000 (or whatever port Next.js picks if 3000 is
already used by the main booking site — run them side by side, e.g.
`npm run dev -- -p 3001`).

Sign in with the admin account you created. Non-admin accounts are
rejected at login.

## What's inside

- **Dashboard** (`/`) — live counts (users, flights, bookings by status),
  total revenue, a status breakdown chart, and the most recent bookings.
- **Flights** (`/flights`) — paginated list, create/edit forms (route,
  timing, fare, baggage rules, segments, aircraft), and activate/
  deactivate. Creating a flight automatically seeds its seat map.
- **Bookings** (`/bookings`) — every booking across all travelers, filter
  by status, admin-override cancel.
- **Payments** (`/payments`) — every transaction, filter by status, total
  successful revenue.
- **Users** (`/users`) — search travelers, lock/unlock accounts, grant or
  revoke admin access.

## Notes

- This app and the main booking frontend are separate Next.js projects
  that both call the same backend — they don't share a codebase or a
  login session (different token storage keys), by design, since you
  asked for a standalone admin site.
- Aircraft management is folded into the Flights page (pick from a
  dropdown when creating/editing a flight — there's no separate aircraft
  list screen since it's rarely needed on its own).
