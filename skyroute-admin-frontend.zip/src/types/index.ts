export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  emailVerified?: boolean;
  createdAt?: number;
  roles: string[];
}

export interface AdminUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  emailVerified: boolean;
  accountLocked: boolean;
  roles: string[];
  createdAt: number;
}

export interface City {
  code: string;
  name: string;
  country: string;
}

export interface FlightSegment {
  airlineCode: string;
  flightNumber: string;
  aircraft: string;
}

export interface FlightOffer {
  id: string;
  fromCode: string;
  toCode: string;
  duration: string;
  departTime: string;
  arriveTime: string;
  stops: number;
  stopLabel: string | null;
  segments: FlightSegment[];
  travelClass: string;
  fareName: string | null;
  priceInr: number;
  baggage: string | null;
  handBaggage: string | null;
  seatSelection: string | null;
  upgradeToFirst: string | null;
  changeFee: string | null;
  refundFee: string | null;
  // Admin-only fields present on /admin/flights responses
  departureDate?: string;
  active?: boolean;
}

export interface Aircraft {
  id: number;
  model: string;
  totalSeats: number;
}

export type BookingStatus = "pending_payment" | "confirmed" | "checked_in" | "cancelled";

export interface BookingPassenger {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  age: string;
  gender: string;
  seniorCitizen: boolean;
  seatId: string | null;
  checkedIn: boolean;
}

export interface Booking {
  pnr: string;
  flightId: string;
  passengers: BookingPassenger[];
  status: BookingStatus;
  contactEmail: string;
  contactPhone: string;
  createdAt: number;
  totalAmount: number;
  transactionId: string | null;
}

export type PaymentMethod = "card" | "upi" | "netbanking" | "wallet";
export type TransactionStatus = "success" | "failed";

export interface Transaction {
  id: string;
  pnr: string;
  method: PaymentMethod;
  amount: number;
  status: TransactionStatus;
  createdAt: number;
  methodLabel: string;
  referenceId: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalFlights: number;
  upcomingFlights: number;
  totalBookings: number;
  confirmedBookings: number;
  checkedInBookings: number;
  cancelledBookings: number;
  pendingPaymentBookings: number;
  totalRevenue: number;
  recentBookings: Booking[];
}
