"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, Save } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { adminFlightsApi } from "@/lib/api/flights";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { Aircraft, FlightOffer, FlightSegment } from "@/types";

export interface FlightFormValue {
  id: string;
  fromCode: string;
  toCode: string;
  departTime: string;
  arriveTime: string;
  duration: string;
  stops: number;
  stopLabel: string;
  travelClass: string;
  fareName: string;
  priceInr: string;
  baggage: string;
  handBaggage: string;
  seatSelection: string;
  upgradeToFirst: string;
  changeFee: string;
  refundFee: string;
  aircraftId: string;
  departureDate: string;
  active: boolean;
  segments: FlightSegment[];
}

const EMPTY_SEGMENT: FlightSegment = { airlineCode: "", flightNumber: "", aircraft: "" };

function fromFlight(flight: FlightOffer): FlightFormValue {
  return {
    id: flight.id,
    fromCode: flight.fromCode,
    toCode: flight.toCode,
    departTime: flight.departTime,
    arriveTime: flight.arriveTime,
    duration: flight.duration,
    stops: flight.stops,
    stopLabel: flight.stopLabel ?? "",
    travelClass: flight.travelClass,
    fareName: flight.fareName ?? "",
    priceInr: String(flight.priceInr),
    baggage: flight.baggage ?? "",
    handBaggage: flight.handBaggage ?? "",
    seatSelection: flight.seatSelection ?? "",
    upgradeToFirst: flight.upgradeToFirst ?? "",
    changeFee: flight.changeFee ?? "",
    refundFee: flight.refundFee ?? "",
    aircraftId: "",
    departureDate: flight.departureDate ?? "",
    active: flight.active ?? true,
    segments: flight.segments.length ? flight.segments : [EMPTY_SEGMENT],
  };
}

function empty(): FlightFormValue {
  return {
    id: "", fromCode: "", toCode: "", departTime: "", arriveTime: "", duration: "",
    stops: 0, stopLabel: "", travelClass: "Economy", fareName: "", priceInr: "",
    baggage: "", handBaggage: "", seatSelection: "", upgradeToFirst: "", changeFee: "",
    refundFee: "", aircraftId: "", departureDate: "", active: true, segments: [EMPTY_SEGMENT],
  };
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-semibold text-slate-600">{label}</span>
      {children}
    </label>
  );
}

const inputCls = "rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-400";

export function FlightForm({ existing }: { existing?: FlightOffer }) {
  const router = useRouter();
  const isEdit = Boolean(existing);
  const [value, setValue] = useState<FlightFormValue>(existing ? fromFlight(existing) : empty());
  const [aircraft, setAircraft] = useState<Aircraft[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    adminFlightsApi.listAircraft().then(setAircraft).catch(() => {});
  }, []);

  function set<K extends keyof FlightFormValue>(key: K, v: FlightFormValue[K]) {
    setValue((prev) => ({ ...prev, [key]: v }));
  }

  function setSegment(i: number, patch: Partial<FlightSegment>) {
    setValue((prev) => ({
      ...prev,
      segments: prev.segments.map((s, idx) => (idx === i ? { ...s, ...patch } : s)),
    }));
  }

  function addSegment() {
    setValue((prev) => ({ ...prev, segments: [...prev.segments, { ...EMPTY_SEGMENT }] }));
  }

  function removeSegment(i: number) {
    setValue((prev) => ({ ...prev, segments: prev.segments.filter((_, idx) => idx !== i) }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!value.priceInr || isNaN(Number(value.priceInr))) {
      toast.error("Enter a valid price.");
      return;
    }
    const payload = {
      id: value.id.trim().toUpperCase(),
      fromCode: value.fromCode.trim().toUpperCase(),
      toCode: value.toCode.trim().toUpperCase(),
      departTime: value.departTime,
      arriveTime: value.arriveTime,
      duration: value.duration,
      stops: Number(value.stops),
      stopLabel: value.stopLabel || undefined,
      travelClass: value.travelClass,
      fareName: value.fareName || undefined,
      priceInr: Number(value.priceInr),
      baggage: value.baggage || undefined,
      handBaggage: value.handBaggage || undefined,
      seatSelection: value.seatSelection || undefined,
      upgradeToFirst: value.upgradeToFirst || undefined,
      changeFee: value.changeFee || undefined,
      refundFee: value.refundFee || undefined,
      aircraftId: value.aircraftId ? Number(value.aircraftId) : null,
      departureDate: value.departureDate,
      segments: value.segments.filter((s) => s.airlineCode && s.flightNumber),
    };

    setSubmitting(true);
    try {
      if (isEdit) {
        await adminFlightsApi.update(value.id, { ...payload, active: value.active });
        toast.success("Flight updated.");
      } else {
        await adminFlightsApi.create(payload);
        toast.success("Flight created.");
      }
      router.push("/flights");
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Couldn't save flight.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="card grid gap-4 p-6 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Flight ID">
          <input required disabled={isEdit} value={value.id} onChange={(e) => set("id", e.target.value)}
            placeholder="e.g. EK112-330" className={inputCls} />
        </Field>
        <Field label="From (IATA code)">
          <input required value={value.fromCode} onChange={(e) => set("fromCode", e.target.value)} placeholder="AMD" className={inputCls} />
        </Field>
        <Field label="To (IATA code)">
          <input required value={value.toCode} onChange={(e) => set("toCode", e.target.value)} placeholder="LHR" className={inputCls} />
        </Field>
        <Field label="Departure date">
          <input required type="date" value={value.departureDate} onChange={(e) => set("departureDate", e.target.value)} className={inputCls} />
        </Field>
        <Field label="Depart time">
          <input required value={value.departTime} onChange={(e) => set("departTime", e.target.value)} placeholder="09:15" className={inputCls} />
        </Field>
        <Field label="Arrive time">
          <input required value={value.arriveTime} onChange={(e) => set("arriveTime", e.target.value)} placeholder="14:40" className={inputCls} />
        </Field>
        <Field label="Duration">
          <input required value={value.duration} onChange={(e) => set("duration", e.target.value)} placeholder="9h 25m" className={inputCls} />
        </Field>
        <Field label="Stops">
          <input required type="number" min={0} value={value.stops} onChange={(e) => set("stops", Number(e.target.value))} className={inputCls} />
        </Field>
        <Field label="Stop label">
          <input value={value.stopLabel} onChange={(e) => set("stopLabel", e.target.value)} placeholder="Non-stop" className={inputCls} />
        </Field>
        <Field label="Travel class">
          <select value={value.travelClass} onChange={(e) => set("travelClass", e.target.value)} className={inputCls}>
            <option>Economy</option>
            <option>Premium Economy</option>
            <option>Business</option>
            <option>First</option>
          </select>
        </Field>
        <Field label="Fare name">
          <input value={value.fareName} onChange={(e) => set("fareName", e.target.value)} placeholder="Saver" className={inputCls} />
        </Field>
        <Field label="Price (INR)">
          <input required type="number" min={0} value={value.priceInr} onChange={(e) => set("priceInr", e.target.value)} className={inputCls} />
        </Field>
        <Field label="Aircraft">
          <select value={value.aircraftId} onChange={(e) => set("aircraftId", e.target.value)} className={inputCls}>
            <option value="">— None —</option>
            {aircraft.map((a) => <option key={a.id} value={a.id}>{a.model} ({a.totalSeats} seats)</option>)}
          </select>
        </Field>
        {isEdit && (
          <Field label="Status">
            <select value={value.active ? "active" : "inactive"} onChange={(e) => set("active", e.target.value === "active")} className={inputCls}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </Field>
        )}
      </div>

      <div className="card grid gap-4 p-6 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="Baggage"><input value={value.baggage} onChange={(e) => set("baggage", e.target.value)} placeholder="23kg" className={inputCls} /></Field>
        <Field label="Hand baggage"><input value={value.handBaggage} onChange={(e) => set("handBaggage", e.target.value)} placeholder="7kg" className={inputCls} /></Field>
        <Field label="Seat selection"><input value={value.seatSelection} onChange={(e) => set("seatSelection", e.target.value)} placeholder="Chargeable" className={inputCls} /></Field>
        <Field label="Upgrade to First"><input value={value.upgradeToFirst} onChange={(e) => set("upgradeToFirst", e.target.value)} className={inputCls} /></Field>
        <Field label="Change fee"><input value={value.changeFee} onChange={(e) => set("changeFee", e.target.value)} placeholder="₹3,500" className={inputCls} /></Field>
        <Field label="Refund fee"><input value={value.refundFee} onChange={(e) => set("refundFee", e.target.value)} placeholder="₹5,000" className={inputCls} /></Field>
      </div>

      <div className="card p-6">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm font-bold text-navy-900">Flight segments</p>
          <Button type="button" variant="outline" size="sm" onClick={addSegment}><Plus size={14} /> Add segment</Button>
        </div>
        <div className="flex flex-col gap-3">
          {value.segments.map((s, i) => (
            <div key={i} className="grid grid-cols-1 gap-3 rounded-xl border border-slate-100 p-4 sm:grid-cols-4">
              <Field label="Airline code">
                <input required value={s.airlineCode} onChange={(e) => setSegment(i, { airlineCode: e.target.value })} placeholder="EK" className={inputCls} />
              </Field>
              <Field label="Flight number">
                <input required value={s.flightNumber} onChange={(e) => setSegment(i, { flightNumber: e.target.value })} placeholder="EK112" className={inputCls} />
              </Field>
              <Field label="Aircraft type">
                <input value={s.aircraft} onChange={(e) => setSegment(i, { aircraft: e.target.value })} placeholder="Boeing 777" className={inputCls} />
              </Field>
              <div className="flex items-end">
                {value.segments.length > 1 && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => removeSegment(i)}>
                    <Trash2 size={14} /> Remove
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={() => router.push("/flights")}>Cancel</Button>
        <Button type="submit" disabled={submitting}>
          <Save size={16} /> {submitting ? "Saving…" : isEdit ? "Save changes" : "Create flight"}
        </Button>
      </div>
    </form>
  );
}
