import { cn } from "@/lib/utils";

const STYLES: Record<string, string> = {
  confirmed: "bg-emerald-100 text-emerald-700",
  checked_in: "bg-sky-100 text-sky-700",
  cancelled: "bg-red-100 text-red-700",
  pending_payment: "bg-amber-100 text-amber-700",
  success: "bg-emerald-100 text-emerald-700",
  failed: "bg-red-100 text-red-700",
  active: "bg-emerald-100 text-emerald-700",
  inactive: "bg-slate-100 text-slate-500",
  locked: "bg-red-100 text-red-700",
  unlocked: "bg-emerald-100 text-emerald-700",
};

const LABELS: Record<string, string> = {
  confirmed: "Confirmed",
  checked_in: "Checked in",
  cancelled: "Cancelled",
  pending_payment: "Pending payment",
  success: "Success",
  failed: "Failed",
  active: "Active",
  inactive: "Inactive",
  locked: "Locked",
  unlocked: "Active",
};

export function Badge({ status }: { status: string }) {
  return (
    <span className={cn("inline-block rounded-full px-2.5 py-1 text-xs font-semibold", STYLES[status] ?? "bg-slate-100 text-slate-600")}>
      {LABELS[status] ?? status}
    </span>
  );
}
