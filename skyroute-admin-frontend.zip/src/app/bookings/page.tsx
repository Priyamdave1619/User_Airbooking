"use client";

import { useCallback, useEffect, useState } from "react";
import { Ticket, XCircle } from "lucide-react";
import { AdminShell } from "@/components/layout/AdminShell";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Pagination } from "@/components/ui/Pagination";
import { adminBookingsApi } from "@/lib/api/bookings";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { Booking } from "@/types";

const STATUSES = [
  { value: "", label: "All statuses" },
  { value: "pending_payment", label: "Pending payment" },
  { value: "confirmed", label: "Confirmed" },
  { value: "checked_in", label: "Checked in" },
  { value: "cancelled", label: "Cancelled" },
];

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(true);
  const [busyPnr, setBusyPnr] = useState<string | null>(null);

  const load = useCallback((s: string, p: number) => {
    setLoading(true);
    adminBookingsApi
      .list(s || undefined, p, 20)
      .then((res) => {
        setBookings(res.content);
        setTotalPages(res.totalPages);
        setTotalElements(res.totalElements);
      })
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load bookings."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(status, page); }, [status, page, load]);

  async function handleCancel(pnr: string) {
    if (!confirm(`Cancel booking ${pnr}? This cannot be undone.`)) return;
    setBusyPnr(pnr);
    try {
      await adminBookingsApi.cancel(pnr);
      toast.success(`Booking ${pnr} cancelled.`);
      load(status, page);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Couldn't cancel booking.");
    } finally {
      setBusyPnr(null);
    }
  }

  return (
    <AdminShell>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Bookings</h1>
          <p className="text-sm text-slate-500">Every reservation across all travelers.</p>
        </div>
        <select
          value={status}
          onChange={(e) => { setStatus(e.target.value); setPage(0); }}
          className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-400"
        >
          {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>

      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex flex-col gap-2 p-5">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-12" />)}
          </div>
        ) : bookings.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <Ticket size={28} className="text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No bookings found</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                <th className="px-5 py-3">PNR</th>
                <th className="px-5 py-3">Flight</th>
                <th className="px-5 py-3">Contact</th>
                <th className="px-5 py-3">Passengers</th>
                <th className="px-5 py-3">Amount</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.pnr} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                  <td className="px-5 py-3 text-sm font-semibold text-navy-900">{b.pnr}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{b.flightId}</td>
                  <td className="px-5 py-3 text-xs text-slate-500">{b.contactEmail}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{b.passengers.length}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">₹{b.totalAmount.toLocaleString("en-IN")}</td>
                  <td className="px-5 py-3"><Badge status={b.status} /></td>
                  <td className="px-5 py-3 text-right">
                    {b.status !== "cancelled" && (
                      <Button variant="danger" size="sm" disabled={busyPnr === b.pnr} onClick={() => handleCancel(b.pnr)}>
                        <XCircle size={13} /> Cancel
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <Pagination page={page} totalPages={totalPages} totalElements={totalElements} onPageChange={setPage} />
      </div>
    </AdminShell>
  );
}
