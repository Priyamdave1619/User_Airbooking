"use client";

import { useCallback, useEffect, useState } from "react";
import { CreditCard, IndianRupee } from "lucide-react";
import { AdminShell } from "@/components/layout/AdminShell";
import { Badge } from "@/components/ui/Badge";
import { Pagination } from "@/components/ui/Pagination";
import { adminPaymentsApi } from "@/lib/api/payments";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { Transaction } from "@/types";

const STATUSES = [
  { value: "", label: "All statuses" },
  { value: "success", label: "Success" },
  { value: "failed", label: "Failed" },
];

export default function PaymentsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [revenue, setRevenue] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback((s: string, p: number) => {
    setLoading(true);
    adminPaymentsApi
      .list(s || undefined, p, 20)
      .then((res) => {
        setTransactions(res.content);
        setTotalPages(res.totalPages);
        setTotalElements(res.totalElements);
      })
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load payments."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(status, page); }, [status, page, load]);
  useEffect(() => { adminPaymentsApi.totalRevenue().then(setRevenue).catch(() => {}); }, []);

  return (
    <AdminShell>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Payments</h1>
          <p className="text-sm text-slate-500">Every transaction processed across all bookings.</p>
        </div>
        <select
          value={status}
          onChange={(e) => { setStatus(e.target.value); setPage(0); }}
          className="rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-sky-400"
        >
          {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>

      {revenue !== null && (
        <div className="card mb-6 flex items-center gap-4 p-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
            <IndianRupee size={20} />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Total successful revenue</p>
            <p className="text-xl font-bold text-navy-900">₹{Number(revenue).toLocaleString("en-IN")}</p>
          </div>
        </div>
      )}

      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex flex-col gap-2 p-5">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-12" />)}
          </div>
        ) : transactions.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <CreditCard size={28} className="text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No transactions found</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                <th className="px-5 py-3">Transaction</th>
                <th className="px-5 py-3">PNR</th>
                <th className="px-5 py-3">Method</th>
                <th className="px-5 py-3">Amount</th>
                <th className="px-5 py-3">Reference</th>
                <th className="px-5 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                  <td className="px-5 py-3 text-sm font-semibold text-navy-900">{t.id}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{t.pnr}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{t.methodLabel}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">₹{t.amount.toLocaleString("en-IN")}</td>
                  <td className="px-5 py-3 text-xs text-slate-400">{t.referenceId}</td>
                  <td className="px-5 py-3 text-right"><Badge status={t.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <Pagination page={page} totalPages={totalPages} totalElements={totalElements} onPageChange={setPage} />
      </div>
    </AdminShell>
  );
}
