"use client";

import { useCallback, useEffect, useState } from "react";
import { Users, Lock, Unlock, ShieldCheck, ShieldOff, Search } from "lucide-react";
import { AdminShell } from "@/components/layout/AdminShell";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Pagination } from "@/components/ui/Pagination";
import { adminUsersApi } from "@/lib/api/users";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { AdminUser } from "@/types";

export default function UsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => { setDebouncedQuery(query); setPage(0); }, 350);
    return () => clearTimeout(t);
  }, [query]);

  const load = useCallback((q: string, p: number) => {
    setLoading(true);
    adminUsersApi
      .list(q || undefined, p, 20)
      .then((res) => {
        setUsers(res.content);
        setTotalPages(res.totalPages);
        setTotalElements(res.totalElements);
      })
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load users."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(debouncedQuery, page); }, [debouncedQuery, page, load]);

  async function toggleLock(u: AdminUser) {
    setBusyId(u.id);
    try {
      await adminUsersApi.setLocked(u.id, !u.accountLocked);
      toast.success(`${u.firstName} ${u.accountLocked ? "unlocked" : "locked"}.`);
      load(debouncedQuery, page);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Couldn't update account.");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleAdmin(u: AdminUser) {
    const isAdmin = u.roles.includes("ROLE_ADMIN");
    const nextRoles = isAdmin ? u.roles.filter((r) => r !== "ROLE_ADMIN") : [...u.roles, "ROLE_ADMIN"];
    setBusyId(u.id);
    try {
      await adminUsersApi.setRoles(u.id, nextRoles.length ? nextRoles : ["ROLE_USER"]);
      toast.success(`${u.firstName} is ${isAdmin ? "no longer an admin" : "now an admin"}.`);
      load(debouncedQuery, page);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Couldn't update roles.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <AdminShell>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Users</h1>
          <p className="text-sm text-slate-500">Search travelers, manage access and admin roles.</p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
          <Search size={15} className="text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search name or email…"
            className="w-56 bg-transparent text-sm outline-none"
          />
        </div>
      </div>

      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex flex-col gap-2 p-5">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-12" />)}
          </div>
        ) : users.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <Users size={28} className="text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No users found</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                <th className="px-5 py-3">Name</th>
                <th className="px-5 py-3">Email</th>
                <th className="px-5 py-3">Phone</th>
                <th className="px-5 py-3">Roles</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const isAdmin = u.roles.includes("ROLE_ADMIN");
                return (
                  <tr key={u.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                    <td className="px-5 py-3 text-sm font-semibold text-navy-900">{u.firstName} {u.lastName}</td>
                    <td className="px-5 py-3 text-xs text-slate-500">{u.email}</td>
                    <td className="px-5 py-3 text-sm text-slate-600">{u.phone ?? "—"}</td>
                    <td className="px-5 py-3">
                      <div className="flex flex-wrap gap-1">
                        {u.roles.map((r) => (
                          <span key={r} className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                            {r.replace("ROLE_", "")}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-5 py-3"><Badge status={u.accountLocked ? "locked" : "unlocked"} /></td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" disabled={busyId === u.id} onClick={() => toggleAdmin(u)}>
                          {isAdmin ? <ShieldOff size={13} /> : <ShieldCheck size={13} />}
                          {isAdmin ? "Revoke admin" : "Make admin"}
                        </Button>
                        <Button
                          variant={u.accountLocked ? "primary" : "danger"}
                          size="sm"
                          disabled={busyId === u.id}
                          onClick={() => toggleLock(u)}
                        >
                          {u.accountLocked ? <Unlock size={13} /> : <Lock size={13} />}
                          {u.accountLocked ? "Unlock" : "Lock"}
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
        <Pagination page={page} totalPages={totalPages} totalElements={totalElements} onPageChange={setPage} />
      </div>
    </AdminShell>
  );
}
