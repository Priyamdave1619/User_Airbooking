"use client";

import { AdminShell } from "@/components/layout/AdminShell";
import { FlightForm } from "@/components/flights/FlightForm";

export default function NewFlightPage() {
  return (
    <AdminShell>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900">New flight</h1>
        <p className="text-sm text-slate-500">Add a flight to the schedule. Seats are generated automatically.</p>
      </div>
      <FlightForm />
    </AdminShell>
  );
}
