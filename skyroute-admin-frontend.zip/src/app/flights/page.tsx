"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Plane, Plus, Power } from "lucide-react";
import { AdminShell } from "@/components/layout/AdminShell";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Pagination } from "@/components/ui/Pagination";
import { adminFlightsApi } from "@/lib/api/flights";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { FlightOffer } from "@/types";

export default function FlightsPage() {
  const [flights, setFlights] = useState<FlightOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [totalElements, setTotalElements] = useState(0);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback((p: number) => {
    setLoading(true);
    adminFlightsApi
      .list(p, 20)
      .then((res) => {
        setFlights(res.content);
        setTotalPages(res.totalPages);
        setTotalElements(res.totalElements);
      })
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load flights."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(page); }, [page, load]);

  async function toggleActive(flight: FlightOffer) {
    setBusyId(flight.id);
    try {
      await adminFlightsApi.setActive(flight.id, !flight.active);
      toast.success(`Flight ${flight.id} ${flight.active ? "deactivated" : "activated"}.`);
      load(page);
    } catch (err) {
      toast.error(err instanceof ApiError ? err.message : "Couldn't update flight status.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <AdminShell>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Flights</h1>
          <p className="text-sm text-slate-500">Manage routes, fares, and seat inventory.</p>
        </div>
        <Link href="/flights/new">
          <Button><Plus size={16} /> New flight</Button>
        </Link>
      </div>

      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex flex-col gap-2 p-5">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-12" />)}
          </div>
        ) : flights.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-16 text-center">
            <Plane size={28} className="text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No flights yet</p>
            <Link href="/flights/new"><Button size="sm" className="mt-2"><Plus size={14} /> Add your first flight</Button></Link>
          </div>
        ) : (
          <table>
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                <th className="px-5 py-3">Flight</th>
                <th className="px-5 py-3">Route</th>
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Class</th>
                <th className="px-5 py-3">Price</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {flights.map((f) => (
                <tr key={f.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                  <td className="px-5 py-3 text-sm font-semibold text-navy-900">{f.id}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{f.fromCode} &rarr; {f.toCode}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{f.departureDate ?? "—"}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">{f.travelClass}</td>
                  <td className="px-5 py-3 text-sm text-slate-600">₹{f.priceInr.toLocaleString("en-IN")}</td>
                  <td className="px-5 py-3"><Badge status={f.active ? "active" : "inactive"} /></td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-2">
                      <Link href={`/flights/${encodeURIComponent(f.id)}/edit`}>
                        <Button variant="outline" size="sm">Edit</Button>
                      </Link>
                      <Button
                        variant={f.active ? "danger" : "primary"}
                        size="sm"
                        disabled={busyId === f.id}
                        onClick={() => toggleActive(f)}
                      >
                        <Power size={13} /> {f.active ? "Deactivate" : "Activate"}
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <Pagination page={page} totalPages={totalPages} totalElements={totalElements} onPageChange={setPage} />
      </div>
    </AdminShell>
  );
}
