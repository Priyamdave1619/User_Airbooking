"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { AdminShell } from "@/components/layout/AdminShell";
import { FlightForm } from "@/components/flights/FlightForm";
import { adminFlightsApi } from "@/lib/api/flights";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { FlightOffer } from "@/types";

export default function EditFlightPage() {
  const params = useParams<{ id: string }>();
  const id = decodeURIComponent(params.id);
  const [flight, setFlight] = useState<FlightOffer | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminFlightsApi
      .get(id)
      .then(setFlight)
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load flight."))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <AdminShell>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900">Edit flight {id}</h1>
        <p className="text-sm text-slate-500">Update route, fare, or availability.</p>
      </div>
      {loading ? (
        <div className="skeleton h-96" />
      ) : flight ? (
        <FlightForm existing={flight} />
      ) : (
        <p className="text-sm text-slate-500">Flight not found.</p>
      )}
    </AdminShell>
  );
}
