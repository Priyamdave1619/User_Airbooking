"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Users, Plane, Ticket, IndianRupee, PlaneTakeoff, CalendarClock, XCircle, CheckCircle2,
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { AdminShell } from "@/components/layout/AdminShell";
import { Badge } from "@/components/ui/Badge";
import { dashboardApi } from "@/lib/api/dashboard";
import { ApiError } from "@/lib/api/client";
import { toast } from "@/components/ui/Toast";
import type { DashboardStats } from "@/types";

function StatCard({
  icon: Icon, label, value, tint,
}: { icon: typeof Users; label: string; value: string; tint: string }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
        <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${tint}`}>
          <Icon size={17} />
        </div>
      </div>
      <p className="mt-3 text-2xl font-bold text-navy-900">{value}</p>
    </div>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dashboardApi
      .stats()
      .then(setStats)
      .catch((err) => toast.error(err instanceof ApiError ? err.message : "Couldn't load dashboard stats."))
      .finally(() => setLoading(false));
  }, []);

  const chartData = stats
    ? [
        { name: "Pending", value: stats.pendingPaymentBookings },
        { name: "Confirmed", value: stats.confirmedBookings },
        { name: "Checked in", value: stats.checkedInBookings },
        { name: "Cancelled", value: stats.cancelledBookings },
      ]
    : [];

  return (
    <AdminShell>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Dashboard</h1>
          <p className="text-sm text-slate-500">Live overview of SkyRoute operations.</p>
        </div>
      </div>

      {loading || !stats ? (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton h-24" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard icon={Users} label="Total users" value={stats.totalUsers.toLocaleString("en-IN")} tint="bg-sky-100 text-sky-600" />
            <StatCard icon={Plane} label="Total flights" value={stats.totalFlights.toLocaleString("en-IN")} tint="bg-navy-800/10 text-navy-800" />
            <StatCard icon={PlaneTakeoff} label="Upcoming flights" value={stats.upcomingFlights.toLocaleString("en-IN")} tint="bg-emerald-100 text-emerald-600" />
            <StatCard icon={Ticket} label="Total bookings" value={stats.totalBookings.toLocaleString("en-IN")} tint="bg-amber-100 text-amber-600" />
            <StatCard icon={CheckCircle2} label="Confirmed" value={stats.confirmedBookings.toLocaleString("en-IN")} tint="bg-emerald-100 text-emerald-600" />
            <StatCard icon={CalendarClock} label="Pending payment" value={stats.pendingPaymentBookings.toLocaleString("en-IN")} tint="bg-amber-100 text-amber-600" />
            <StatCard icon={XCircle} label="Cancelled" value={stats.cancelledBookings.toLocaleString("en-IN")} tint="bg-red-100 text-red-600" />
            <StatCard
              icon={IndianRupee}
              label="Total revenue"
              value={`₹${Number(stats.totalRevenue ?? 0).toLocaleString("en-IN")}`}
              tint="bg-sky-100 text-sky-600"
            />
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_1.4fr]">
            <div className="card p-5">
              <p className="mb-4 text-sm font-bold text-navy-900">Bookings by status</p>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#94a3b8" allowDecimals={false} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#2e6bff" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="card overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <p className="text-sm font-bold text-navy-900">Recent bookings</p>
                <Link href="/bookings" className="text-xs font-semibold text-sky-600 hover:underline">
                  View all
                </Link>
              </div>
              <table>
                <tbody>
                  {stats.recentBookings.length === 0 && (
                    <tr><td className="px-5 py-6 text-center text-sm text-slate-400">No bookings yet.</td></tr>
                  )}
                  {stats.recentBookings.map((b) => (
                    <tr key={b.pnr} className="border-b border-slate-50 last:border-0">
                      <td className="px-5 py-3 text-sm font-semibold text-navy-900">{b.pnr}</td>
                      <td className="px-5 py-3 text-xs text-slate-500">{b.contactEmail}</td>
                      <td className="px-5 py-3 text-sm text-slate-600">₹{b.totalAmount.toLocaleString("en-IN")}</td>
                      <td className="px-5 py-3 text-right"><Badge status={b.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </AdminShell>
  );
}
