"use client";

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import type { User } from "@/types";
import { authApi } from "@/lib/api/auth";
import { getAccessToken, getRefreshToken, setTokens, clearTokens, ApiError } from "@/lib/api/client";

interface AuthContextValue {
  admin: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshAdmin = useCallback(async () => {
    if (!getAccessToken()) {
      setAdmin(null);
      return;
    }
    try {
      const me = await authApi.me();
      if (!me.roles?.includes("ROLE_ADMIN")) {
        clearTokens();
        setAdmin(null);
        return;
      }
      setAdmin(me);
    } catch {
      clearTokens();
      setAdmin(null);
    }
  }, []);

  useEffect(() => {
    (async () => {
      await refreshAdmin();
      setIsLoading(false);
    })();
    const handler = () => refreshAdmin();
    window.addEventListener("skyroute-admin-auth-change", handler);
    return () => window.removeEventListener("skyroute-admin-auth-change", handler);
  }, [refreshAdmin]);

  const login = useCallback(async (email: string, password: string) => {
    try {
      const res = await authApi.login(email, password);
      if (!res.user.roles?.includes("ROLE_ADMIN")) {
        return { ok: false, error: "This account doesn't have admin access." };
      }
      setTokens(res.accessToken, res.refreshToken);
      setAdmin(res.user);
      return { ok: true };
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Login failed. Please try again.";
      return { ok: false, error: message };
    }
  }, []);

  const logout = useCallback(() => {
    const refreshToken = getRefreshToken();
    if (refreshToken) authApi.logout(refreshToken).catch(() => {});
    clearTokens();
    setAdmin(null);
  }, []);

  return (
    <AuthContext.Provider value={{ admin, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
