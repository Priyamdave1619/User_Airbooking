import { api } from "./client";
import type { PageResponse } from "./client";
import type { Aircraft, FlightOffer, FlightSegment } from "@/types";

export interface CreateFlightPayload {
  id: string;
  fromCode: string;
  toCode: string;
  departTime: string;
  arriveTime: string;
  duration: string;
  stops: number;
  stopLabel?: string;
  travelClass: string;
  fareName?: string;
  priceInr: number;
  baggage?: string;
  handBaggage?: string;
  seatSelection?: string;
  upgradeToFirst?: string;
  changeFee?: string;
  refundFee?: string;
  aircraftId?: number | null;
  departureDate: string;
  segments: FlightSegment[];
}

export interface UpdateFlightPayload extends CreateFlightPayload {
  active: boolean;
}

export const adminFlightsApi = {
  list: (page = 0, size = 20) =>
    api.get<PageResponse<FlightOffer>>("/admin/flights", { query: { page, size } }),

  get: (id: string) => api.get<FlightOffer>(`/admin/flights/${encodeURIComponent(id)}`),

  create: (payload: CreateFlightPayload) => api.post<FlightOffer>("/admin/flights", payload),

  update: (id: string, payload: Omit<UpdateFlightPayload, "id">) =>
    api.put<FlightOffer>(`/admin/flights/${encodeURIComponent(id)}`, payload),

  setActive: (id: string, active: boolean) =>
    api.patch<FlightOffer>(`/admin/flights/${encodeURIComponent(id)}/active`, { active }),

  listAircraft: () => api.get<Aircraft[]>("/admin/flights/aircraft"),

  createAircraft: (model: string, totalSeats: number) =>
    api.post<Aircraft>("/admin/flights/aircraft", { model, totalSeats }),
};
