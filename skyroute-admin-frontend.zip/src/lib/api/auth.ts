import { api } from "./client";
import type { User } from "@/types";

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  expiresInSeconds: number;
  user: User;
}

export const authApi = {
  login: (email: string, password: string) =>
    api.post<AuthResponse>("/auth/login", { email, password, rememberMe: true }, { auth: false }),

  logout: (refreshToken: string) => api.post<void>("/auth/logout", { refreshToken }, { auth: false }),

  me: () => api.get<User>("/auth/me"),
};
