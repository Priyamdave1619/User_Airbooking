import { api } from "./client";
import type { PageResponse } from "./client";
import type { Transaction } from "@/types";

export const adminPaymentsApi = {
  list: (status: string | undefined, page = 0, size = 20) =>
    api.get<PageResponse<Transaction>>("/admin/payments", { query: { status, page, size } }),

  totalRevenue: () => api.get<number>("/admin/payments/revenue"),
};
