import { api } from "./client";
import type { PageResponse } from "./client";
import type { AdminUser } from "@/types";

export const adminUsersApi = {
  list: (q: string | undefined, page = 0, size = 20) =>
    api.get<PageResponse<AdminUser>>("/admin/users", { query: { q, page, size } }),

  get: (id: string) => api.get<AdminUser>(`/admin/users/${encodeURIComponent(id)}`),

  setLocked: (id: string, locked: boolean) =>
    api.patch<AdminUser>(`/admin/users/${encodeURIComponent(id)}/lock`, { locked }),

  setRoles: (id: string, roles: string[]) =>
    api.put<AdminUser>(`/admin/users/${encodeURIComponent(id)}/roles`, { roles }),
};
