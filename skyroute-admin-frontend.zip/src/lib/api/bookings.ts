import { api } from "./client";
import type { PageResponse } from "./client";
import type { Booking } from "@/types";

export const adminBookingsApi = {
  list: (status: string | undefined, page = 0, size = 20) =>
    api.get<PageResponse<Booking>>("/admin/bookings", { query: { status, page, size } }),

  get: (pnr: string) => api.get<Booking>(`/admin/bookings/${encodeURIComponent(pnr)}`),

  cancel: (pnr: string) => api.post<void>(`/admin/bookings/${encodeURIComponent(pnr)}/cancel`),
};
