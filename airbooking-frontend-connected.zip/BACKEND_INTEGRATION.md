# SkyRoute — Frontend wired to the real backend

This app previously ran entirely on a client-side "mock backend"
(`src/lib/store/db.ts` + `localStorage`). It now talks to the real
SkyRoute Airlines Spring Boot API for **every** feature: auth, flight
search, seat locking, bookings, payments, check-in, profile, and
notifications.

## 1. Run the backend

From the backend project root:

```bash
docker-compose up   # brings up Postgres + the Spring Boot app
# or, if you're running it directly:
./mvnw spring-boot:run
```

By default it listens on `http://localhost:8080`, with every endpoint
under the `/api/v1` prefix (e.g. `http://localhost:8080/api/v1/auth/login`).
Check `SECRETS.md` / `application.yml` in the backend project for any
required environment variables (DB connection, JWT secret, mail sender
for OTPs, etc.) before starting it.

## 2. Point the frontend at it

```bash
cp .env.local.example .env.local
```

`.env.local` sets:

```
NEXT_PUBLIC_API_BASE_URL=http://localhost:8080/api/v1
```

Change this if your backend runs elsewhere (a different port, a deployed
URL, behind a proxy, etc).

## 3. Install & run

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## What changed

- **`src/lib/api/`** — new API client layer. `client.ts` handles the
  request/response envelope the backend uses
  (`{ success, message, data, errors }`), attaches the JWT access token,
  and silently refreshes it on a 401 using the stored refresh token.
  One file per domain: `auth.ts`, `flights.ts`, `bookings.ts`, `seats.ts`,
  `checkin.ts`, `payments.ts`, `profile.ts`, `notifications.ts`.
- **`src/context/AuthContext.tsx`** — now backed by real JWT login/
  register/refresh/logout calls instead of a mocked user object in
  `localStorage`.
- **`src/lib/data/cities.ts`** — cities are fetched once from
  `GET /cities` and cached in memory (`findCity()` stays synchronous for
  existing call sites; `useCities()` is a reactive hook for dropdowns).
- **`src/hooks/useSeatMap.ts`** — polls the real
  `GET /seats/{flightId}` seat map every few seconds and calls the real
  lock/release endpoints, instead of reading/writing `localStorage`.
- **Removed**: `src/lib/store/db.ts` (the whole mock backend) and the
  seeded-seat-data generator in `seatMapGenerator.ts` (its pure cabin
  *layout* helpers, used only for rendering, were kept).
- Every page that previously read from the mock store — search results,
  seat selection, passenger details, payment, my bookings, payment
  history, check-in, seat change, profile — now calls the matching
  backend endpoint and handles loading/error states.

## Known gaps / things worth knowing

- **Economy Class / Flying Returns pages**: the backend doesn't expose a
  "list every flight" endpoint (only search-by-route-and-date, or
  get-by-id). The Economy Class page searches a fixed demo route
  (`AMD → LHR`) to match the seed data — swap `FEATURED_ROUTES` in
  `src/app/economy-class/page.tsx` for your real popular routes once you
  have more flight data.
- **`/otp-verification`**: this page wasn't linked from anywhere in the
  app and drove a generic mock OTP flow. The real backend only verifies
  OTPs as part of two specific flows (`/auth/verify-registration` and
  `/auth/reset-password`), so this page now just forwards people to
  `/register` or `/forgot-password` depending on the `purpose` query
  param, instead of faking a verification result.
- **Avatar upload**: the backend's `/profile/avatar` endpoint takes the
  avatar as a `avatarUrl` query string, not a file upload — the frontend
  reads the chosen file as a data URL and sends that. Fine for small demo
  images; swap in real object storage + a URL if you need production
  file uploads.
