import { api } from "./client";
import type { City, FlightOffer } from "@/types";

export const flightsApi = {
  getCities: () => api.get<City[]>("/cities", { auth: false }),

  search: (from: string, to: string, date: string, travelClass?: string) =>
    api.get<FlightOffer[]>("/flights/search", {
      auth: false,
      query: { from, to, date, travelClass },
    }),

  getById: (id: string) => api.get<FlightOffer>(`/flights/${encodeURIComponent(id)}`, { auth: false }),
};

/* ---------------- Lightweight in-memory caches ----------------
 * Many pages in the booking flow (seat selection, passenger details,
 * payment, check-in, seat change, my-bookings) all need the same
 * FlightOffer by id. There's no bulk "list all flights" endpoint on the
 * backend (flights are looked up by search or by id), so we memoize
 * getById() calls for the lifetime of the tab to avoid refetching the
 * same flight repeatedly as the user moves through the flow.
 */
const flightCache = new Map<string, FlightOffer>();

export async function getFlightCached(id: string): Promise<FlightOffer | null> {
  if (flightCache.has(id)) return flightCache.get(id)!;
  try {
    const flight = await flightsApi.getById(id);
    flightCache.set(id, flight);
    return flight;
  } catch {
    return null;
  }
}
