import { api } from "./client";
import type { Booking, BoardingPassData } from "@/types";

export const checkInApi = {
  lookup: (pnr: string, contactEmail: string) =>
    api.post<Booking>("/checkin/lookup", { pnr, contactEmail }, { auth: false }),

  checkIn: (pnr: string, contactEmail: string) =>
    api.post<BoardingPassData[]>("/checkin", { pnr, contactEmail }, { auth: false }),

  changeSeat: (pnr: string, passengerId: string, newSeatId: string) =>
    api.post<BoardingPassData>(
      "/checkin/seat",
      { pnr, passengerId, newSeatId },
      { auth: false }
    ),
};
