import { api } from "./client";
import type { User } from "@/types";

export interface UpdateProfilePayload {
  firstName?: string;
  lastName?: string;
  phone?: string;
  gender?: string;
  dateOfBirth?: string;
  nationality?: string;
  passportNumber?: string;
  passportExpiry?: string;
  passportCountry?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
}

export const profileApi = {
  update: (payload: UpdateProfilePayload) => api.put<User>("/profile", payload),

  updateAvatar: (avatarUrl: string) =>
    api.put<User>("/profile/avatar", undefined, { query: { avatarUrl } }),
};
