import { api } from "./client";
import type { PaymentMethod, Transaction } from "@/types";

export interface ProcessPaymentPayload {
  pnr: string;
  method: PaymentMethod;
  amount: number;
  idempotencyKey: string;
  cardNumberLast4?: string;
  upiId?: string;
  bankCode?: string;
  walletProvider?: string;
}

export const paymentsApi = {
  pay: (payload: ProcessPaymentPayload) =>
    api.post<Transaction>("/payments", payload, { auth: false }),

  bookingTransactions: (pnr: string) =>
    api.get<Transaction[]>(`/payments/booking/${encodeURIComponent(pnr)}`, { auth: false }),

  myTransactions: () => api.get<Transaction[]>("/payments/me"),
};

export function generateIdempotencyKey(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `idem-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
