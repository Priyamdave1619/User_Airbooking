/**
 * Base URL of the SkyRoute Airlines Spring Boot backend.
 *
 * Set NEXT_PUBLIC_API_BASE_URL in `.env.local` to point at your backend,
 * e.g. NEXT_PUBLIC_API_BASE_URL=http://localhost:8080/api/v1
 *
 * Falls back to localhost:8080 (the backend's default `server.port`) with
 * the `/api/v1` prefix used by every controller in the backend.
 */
export const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/\/$/, "") ??
  "http://localhost:8080/api/v1";
