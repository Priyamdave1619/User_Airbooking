import { api } from "./client";
import type { Seat } from "@/types";

export interface SeatLockResult {
  flightId: string;
  seatId: string;
  lockedBy: string;
  lockedAtEpochMs: number;
  ttlSeconds: number;
}

export const seatsApi = {
  getSeatMap: (flightId: string, sessionId: string) =>
    api.get<Seat[]>(`/seats/${encodeURIComponent(flightId)}`, {
      auth: false,
      query: { sessionId },
    }),

  lockSeat: (flightId: string, seatId: string, sessionId: string) =>
    api.post<SeatLockResult>("/seats/lock", { flightId, seatId, sessionId }, { auth: false }),

  releaseSeat: (flightId: string, seatId: string, sessionId: string) =>
    api.delete<void>("/seats/lock", { flightId, seatId, sessionId }, { auth: false }),

  releaseAll: (flightId: string, sessionId: string) =>
    api.delete<void>("/seats/lock/all", undefined, {
      auth: false,
      query: { flightId, sessionId },
    }),
};
