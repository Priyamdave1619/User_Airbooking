import { api } from "./client";
import type { PageResponse } from "./client";
import type { Booking, BookingPassenger } from "@/types";

export interface CreateBookingPayload {
  flightId: string;
  passengers: Omit<BookingPassenger, "id" | "checkedIn">[];
  contactEmail: string;
  contactPhone: string;
  sessionId: string;
}

export const bookingsApi = {
  create: (payload: CreateBookingPayload) => api.post<Booking>("/bookings", payload),

  getByPnr: (pnr: string) => api.get<Booking>(`/bookings/${encodeURIComponent(pnr)}`, { auth: false }),

  myBookings: (page = 0, size = 20) =>
    api.get<PageResponse<Booking>>("/bookings/me", { query: { page, size } }),

  cancel: (pnr: string) => api.post<void>(`/bookings/${encodeURIComponent(pnr)}/cancel`),
};
