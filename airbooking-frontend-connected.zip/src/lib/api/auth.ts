import { api } from "./client";
import type { User } from "@/types";

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  expiresInSeconds: number;
  user: User;
}

export interface RegisterPayload {
  firstName: string;
  lastName?: string;
  email: string;
  password: string;
  phone?: string;
}

export type OtpPurpose =
  | "registration"
  | "password_reset"
  | "email_verification"
  | "mobile_verification";

export const authApi = {
  register: (payload: RegisterPayload) => api.post<void>("/auth/register", payload, { auth: false }),

  verifyRegistration: (target: string, purpose: OtpPurpose, code: string) =>
    api.post<AuthResponse>(
      "/auth/verify-registration",
      { target, purpose, code },
      { auth: false }
    ),

  sendOtp: (target: string, purpose: OtpPurpose) =>
    api.post<void>("/auth/otp/send", { target, purpose }, { auth: false }),

  login: (email: string, password: string, rememberMe = false) =>
    api.post<AuthResponse>("/auth/login", { email, password, rememberMe }, { auth: false }),

  refresh: (refreshToken: string) =>
    api.post<AuthResponse>("/auth/refresh", { refreshToken }, { auth: false }),

  logout: (refreshToken: string) =>
    api.post<void>("/auth/logout", { refreshToken }, { auth: false }),

  logoutAll: () => api.post<void>("/auth/logout-all"),

  forgotPassword: (email: string) =>
    api.post<void>("/auth/forgot-password", { email }, { auth: false }),

  resetPassword: (email: string, otpCode: string, newPassword: string) =>
    api.post<void>(
      "/auth/reset-password",
      { email, otpCode, newPassword },
      { auth: false }
    ),

  changePassword: (currentPassword: string, newPassword: string) =>
    api.post<void>("/auth/change-password", { currentPassword, newPassword }),

  me: () => api.get<User>("/auth/me"),
};
