import { api } from "./client";
import type { PageResponse } from "./client";

export interface NotificationItem {
  id: number;
  title: string;
  message: string;
  type: string;
  read: boolean;
  createdAt: number;
}

export const notificationsApi = {
  list: (page = 0, size = 20) =>
    api.get<PageResponse<NotificationItem>>("/notifications", { query: { page, size } }),

  markRead: (id: number) => api.post<void>(`/notifications/${id}/read`),
};
