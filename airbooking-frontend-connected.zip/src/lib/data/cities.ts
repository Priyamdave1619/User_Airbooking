"use client";

import { useSyncExternalStore } from "react";
import { flightsApi } from "@/lib/api/flights";
import type { City } from "@/types";

let citiesCache: City[] = [];
let loaded = false;
let loadingPromise: Promise<City[]> | null = null;
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((l) => l());
}

/** Fetches the city list from the backend once and caches it for the tab's
 * lifetime. Safe to call repeatedly — subsequent calls reuse the same
 * in-flight/completed request. */
export function loadCities(): Promise<City[]> {
  if (loaded) return Promise.resolve(citiesCache);
  if (loadingPromise) return loadingPromise;

  loadingPromise = flightsApi
    .getCities()
    .then((data) => {
      citiesCache = data;
      loaded = true;
      notify();
      return data;
    })
    .catch(() => {
      loadingPromise = null;
      return citiesCache;
    });

  return loadingPromise;
}

/** Synchronous lookup against whatever is currently cached. Returns
 * `undefined` until `loadCities()` has resolved at least once — call
 * `loadCities()` (e.g. from a root-level effect) early in the app
 * lifecycle so this is warm by the time it matters. */
export function findCity(code: string): City | undefined {
  return citiesCache.find((c) => c.code === code);
}

export function getCitiesSnapshot(): City[] {
  return citiesCache;
}

/** React hook for components that render a live city list (e.g. search
 * dropdowns) and need to re-render once the backend data arrives. */
export function useCities(): City[] {
  // Idempotent — kicks off the fetch if it hasn't started yet.
  loadCities();
  return useSyncExternalStore(
    (callback) => {
      listeners.add(callback);
      return () => listeners.delete(callback);
    },
    getCitiesSnapshot,
    () => []
  );
}
