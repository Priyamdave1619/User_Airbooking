"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from "react";
import { User } from "@/types";
import { authApi, profileApi } from "@/lib/api";
import type { UpdateProfilePayload } from "@/lib/api";
import {
  getAccessToken,
  getRefreshToken,
  setTokens,
  clearTokens,
  ApiError,
} from "@/lib/api/client";
import { loadCities } from "@/lib/data/cities";

interface AuthContextValue {
  user: User | null;
  login: (email: string, password: string, rememberMe?: boolean) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  updateProfile: (updates: UpdateProfilePayload) => Promise<{ ok: boolean; error?: string }>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ ok: boolean; error?: string }>;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    if (!getAccessToken()) {
      setUser(null);
      return;
    }
    try {
      const me = await authApi.me();
      setUser(me);
    } catch {
      // Token invalid/expired beyond refresh — treat as logged out.
      clearTokens();
      setUser(null);
    }
  }, []);

  useEffect(() => {
    // Warm the reference-data cache (cities dropdowns etc.) as early as
    // possible so it's ready by the time any page needs it.
    loadCities();

    (async () => {
      await refreshUser();
      setIsLoading(false);
    })();

    // Keep multiple tabs / components in sync when tokens change.
    const handler = () => refreshUser();
    window.addEventListener("skyroute-auth-change", handler);
    return () => window.removeEventListener("skyroute-auth-change", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = useCallback(
    async (email: string, password: string, rememberMe = false) => {
      try {
        const res = await authApi.login(email, password, rememberMe);
        setTokens(res.accessToken, res.refreshToken);
        setUser(res.user);
        return { ok: true };
      } catch (err) {
        const message = err instanceof ApiError ? err.message : "Login failed. Please try again.";
        return { ok: false, error: message };
      }
    },
    []
  );

  const logout = useCallback(() => {
    const refreshToken = getRefreshToken();
    if (refreshToken) {
      // Best-effort — don't block the UI on this.
      authApi.logout(refreshToken).catch(() => {});
    }
    clearTokens();
    setUser(null);
  }, []);

  const updateProfile = useCallback(async (updates: UpdateProfilePayload) => {
    try {
      const updated = await profileApi.update(updates);
      setUser(updated);
      return { ok: true };
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Couldn't update profile.";
      return { ok: false, error: message };
    }
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    try {
      await authApi.changePassword(currentPassword, newPassword);
      return { ok: true };
    } catch (err) {
      const message = err instanceof ApiError ? err.message : "Couldn't change password.";
      return { ok: false, error: message };
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, login, logout, refreshUser, updateProfile, changePassword, isLoading }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}
