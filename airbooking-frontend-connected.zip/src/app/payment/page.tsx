"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { PageShell } from "@/components/layout/PageShell";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { PaymentMethodTabs } from "@/components/payment/PaymentMethodTabs";
import { CardForm, CardFormValue } from "@/components/payment/CardForm";
import { UpiForm } from "@/components/payment/UpiForm";
import { NetBankingForm } from "@/components/payment/NetBankingForm";
import { WalletForm } from "@/components/payment/WalletForm";
import { PaymentSummary } from "@/components/payment/PaymentSummary";
import { ProcessingOverlay } from "@/components/payment/ProcessingOverlay";
import { PaymentSuccess } from "@/components/payment/PaymentSuccess";
import { PaymentFailure } from "@/components/payment/PaymentFailure";
import { getFlightCached } from "@/lib/api/flights";
import { bookingsApi } from "@/lib/api/bookings";
import { paymentsApi, generateIdempotencyKey } from "@/lib/api/payments";
import { ApiError } from "@/lib/api/client";
import { generateReceiptPdf } from "@/lib/pdf/generateReceipt";
import { Booking, FlightOffer, PaymentMethod, PaymentStatus, Transaction } from "@/types";

const methodLabels: Record<PaymentMethod, string> = {
  card: "Credit / Debit Card",
  upi: "UPI",
  netbanking: "Net Banking",
  wallet: "Wallet",
};

function PaymentContent() {
  const router = useRouter();
  const params = useSearchParams();
  const pnr = params.get("booking") ?? "";

  const [booking, setBooking] = useState<Booking | null>(null);
  const [flight, setFlight] = useState<FlightOffer | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);

  useEffect(() => {
    if (!pnr) { setLoadFailed(true); return; }
    let cancelled = false;
    bookingsApi
      .getByPnr(pnr)
      .then(async (b) => {
        if (cancelled) return;
        setBooking(b);
        const f = await getFlightCached(b.flightId);
        if (!cancelled) setFlight(f);
      })
      .catch(() => {
        if (!cancelled) setLoadFailed(true);
      });
    return () => { cancelled = true; };
  }, [pnr]);

  const [method, setMethod] = useState<PaymentMethod>("card");
  const [card, setCard] = useState<CardFormValue>({ number: "", name: "", expiry: "", cvv: "" });
  const [upiId, setUpiId] = useState("");
  const [bank, setBank] = useState("");
  const [wallet, setWallet] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [status, setStatus] = useState<PaymentStatus>("idle");
  const [transaction, setTransaction] = useState<Transaction | null>(null);
  const [failureReason, setFailureReason] = useState("");
  const idempotencyKey = useState(() => generateIdempotencyKey())[0];

  if (loadFailed) {
    return (
      <Container className="py-20 text-center">
        <h1 className="text-xl font-bold text-navy-900">Booking not found</h1>
        <p className="mt-2 text-slate-500">
          We couldn&apos;t find a pending booking for that reference. Please start a new
          search.
        </p>
        <Button className="mt-6" onClick={() => router.push("/")}>
          Back to home
        </Button>
      </Container>
    );
  }

  if (!booking || !flight) {
    return <div className="py-20 text-center text-slate-500">Loading payment details…</div>;
  }

  const activeBooking = booking;
  const activeFlight = flight;

  function validate(): boolean {
    const nextErrors: Record<string, string> = {};
    if (method === "card") {
      const digits = card.number.replace(/\s/g, "");
      if (digits.length < 16) nextErrors.number = "Enter a valid 16-digit card number";
      if (!card.name) nextErrors.name = "Enter the name on the card";
      if (!/^\d{2}\/\d{2}$/.test(card.expiry)) nextErrors.expiry = "Use MM/YY format";
      if (card.cvv.length < 3) nextErrors.cvv = "Enter a valid CVV";
    } else if (method === "upi") {
      if (!/^[\w.-]+@[\w.-]+$/.test(upiId)) nextErrors.upi = "Enter a valid UPI ID (e.g. name@bank)";
    } else if (method === "netbanking") {
      if (!bank) nextErrors.bank = "Select your bank";
    } else if (method === "wallet") {
      if (!wallet) nextErrors.wallet = "Select a wallet";
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  async function handlePay() {
    if (!validate()) return;
    setStatus("processing");

    try {
      const txn = await paymentsApi.pay({
        pnr: activeBooking.pnr,
        method,
        amount: activeBooking.totalAmount,
        idempotencyKey,
        cardNumberLast4: method === "card" ? card.number.replace(/\s/g, "").slice(-4) : undefined,
        upiId: method === "upi" ? upiId : undefined,
        bankCode: method === "netbanking" ? bank : undefined,
        walletProvider: method === "wallet" ? wallet : undefined,
      });
      setTransaction(txn);
      if (txn.status === "success") {
        const refreshed = await bookingsApi.getByPnr(activeBooking.pnr).catch(() => null);
        if (refreshed) setBooking(refreshed);
        setStatus("success");
      } else {
        setFailureReason(
          "Your payment couldn't be completed. This often happens with insufficient funds or incorrect details."
        );
        setStatus("failed");
      }
    } catch (err) {
      setFailureReason(
        err instanceof ApiError ? err.message : "Something went wrong while processing your payment."
      );
      setStatus("failed");
    }
  }

  if (status === "success" && transaction) {
    return (
      <PaymentSuccess
        booking={{ ...activeBooking, status: "confirmed" }}
        flight={activeFlight}
        transaction={transaction}
        onDownloadReceipt={() => generateReceiptPdf(activeBooking, activeFlight, transaction)}
      />
    );
  }

  if (status === "failed") {
    return (
      <PaymentFailure
        reason={failureReason}
        referenceId={transaction?.referenceId ?? ""}
        onRetry={() => setStatus("idle")}
      />
    );
  }

  return (
    <>
      {status === "processing" && (
        <ProcessingOverlay label={`Processing your ${methodLabels[method]} payment…`} />
      )}

      <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="brand-card p-6 sm:p-8">
          <h1 className="text-xl font-bold text-navy-900">Choose a payment method</h1>
          <p className="mt-1 text-sm text-slate-500">
            All transactions are encrypted end-to-end.
          </p>

          <div className="mt-6">
            <PaymentMethodTabs value={method} onChange={setMethod} />
          </div>

          <div className="mt-8">
            {method === "card" && <CardForm value={card} onChange={setCard} errors={errors} />}
            {method === "upi" && (
              <UpiForm value={upiId} onChange={setUpiId} error={errors.upi} />
            )}
            {method === "netbanking" && (
              <NetBankingForm value={bank} onChange={setBank} error={errors.bank} />
            )}
            {method === "wallet" && (
              <WalletForm value={wallet} onChange={setWallet} error={errors.wallet} />
            )}
          </div>

          <Button size="lg" className="mt-8 w-full" onClick={handlePay}>
            Pay INR {activeBooking.totalAmount.toLocaleString("en-IN")}
          </Button>
        </div>

        <PaymentSummary booking={activeBooking} flight={activeFlight} />
      </div>
    </>
  );
}

export default function PaymentPage() {
  return (
    <PageShell>
      <div className="bg-slate-50 py-10">
        <Container className="max-w-5xl">
          <Suspense fallback={<div className="py-20 text-center text-slate-500">Loading payment details…</div>}>
            <PaymentContent />
          </Suspense>
        </Container>
      </div>
    </PageShell>
  );
}
