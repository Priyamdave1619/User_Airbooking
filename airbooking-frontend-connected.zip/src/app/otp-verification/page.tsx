"use client";

/**
 * This page previously drove a fully client-side "mock" OTP flow against
 * src/lib/store/db.ts for arbitrary purposes (registration, password reset,
 * generic email/mobile verification).
 *
 * The real backend only exposes OTP verification as part of two specific
 * flows — POST /auth/verify-registration (registration) and
 * POST /auth/reset-password (password_reset), each of which also needs
 * extra data (a password) beyond just the code. There's no standalone
 * "verify this OTP" endpoint for a generic purpose, so rather than fake a
 * verification result here, this page now sends people to the real flow
 * that owns their purpose. It isn't linked from anywhere else in the app.
 */

import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { PageShell } from "@/components/layout/PageShell";
import { Container } from "@/components/ui/Container";
import type { OtpPurpose } from "@/lib/api/auth";

const REDIRECT_FOR_PURPOSE: Record<OtpPurpose, string> = {
  registration: "/register",
  password_reset: "/forgot-password",
  email_verification: "/profile",
  mobile_verification: "/profile",
};

function OtpVerificationContent() {
  const router = useRouter();
  const params = useSearchParams();
  const purpose = (params.get("purpose") ?? "email_verification") as OtpPurpose;

  useEffect(() => {
    const target = REDIRECT_FOR_PURPOSE[purpose] ?? "/profile";
    const t = setTimeout(() => router.replace(target), 1200);
    return () => clearTimeout(t);
  }, [purpose, router]);

  return (
    <div className="bg-slate-50 py-20">
      <Container>
        <div className="mx-auto max-w-md text-center">
          <div className="brand-card p-8">
            <p className="text-lg font-bold text-navy-900">Taking you to verification…</p>
            <p className="mt-2 text-sm text-slate-500">
              OTP verification now happens directly inside the sign-up and
              password-reset flows.
            </p>
          </div>
        </div>
      </Container>
    </div>
  );
}

export default function OtpVerificationPage() {
  return (
    <PageShell>
      <Suspense fallback={<div className="py-20 text-center text-slate-400">Loading…</div>}>
        <OtpVerificationContent />
      </Suspense>
    </PageShell>
  );
}
