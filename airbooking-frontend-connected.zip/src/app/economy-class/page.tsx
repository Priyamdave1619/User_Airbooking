"use client";

import { useEffect, useState } from "react";
import { PageShell } from "@/components/layout/PageShell";
import { PageHeader } from "@/components/ui/PageHeader";
import { Container } from "@/components/ui/Container";
import { FlightResultCard } from "@/components/booking/FlightResultCard";
import { flightsApi } from "@/lib/api";
import type { FlightOffer } from "@/types";

// There's no "browse all flights" endpoint on the backend — flights are
// only reachable via search-by-route-and-date or get-by-id. This page
// showcases Economy fares for the seeded demo route; wire it up to your
// own popular-routes list once you have real flight data.
const FEATURED_ROUTES: { from: string; to: string }[] = [
  { from: "AMD", to: "LHR" },
];

function defaultDate(daysOut: number) {
  return new Date(Date.now() + daysOut * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

export default function EconomyClassPage() {
  const [economyFares, setEconomyFares] = useState<FlightOffer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    Promise.all(
      FEATURED_ROUTES.map((r) =>
        flightsApi
          .search(r.from, r.to, defaultDate(5), "Economy")
          .catch(() => [] as FlightOffer[])
      )
    ).then((results) => {
      if (cancelled) return;
      setEconomyFares(results.flat().filter((f) => f.travelClass === "Economy"));
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, []);

  const cheapest = economyFares.length
    ? Math.min(...economyFares.map((f) => f.priceInr))
    : null;

  return (
    <PageShell>
      <PageHeader title="Economy Class" />

      <Container className="py-16">
        <div className="brand-card mb-8 flex flex-wrap items-center justify-between gap-4 p-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-sky-600">
              Economy fares
            </p>
            <h1 className="text-2xl font-bold text-navy-900">
              Lowest price for all passengers
            </h1>
          </div>
          {cheapest !== null && (
            <p className="text-2xl font-bold text-navy-900">
              from INR {cheapest.toLocaleString("en-IN")}
            </p>
          )}
        </div>

        {loading ? (
          <p className="text-center text-slate-400">Loading fares…</p>
        ) : economyFares.length > 0 ? (
          <div className="flex flex-col gap-4">
            {economyFares.map((offer) => (
              <FlightResultCard key={offer.id} offer={offer} />
            ))}
          </div>
        ) : (
          <p className="text-center text-slate-500">
            No Economy fares available right now — try a different route from the home page.
          </p>
        )}
      </Container>
    </PageShell>
  );
}
