"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Seat } from "@/types";
import { seatsApi } from "@/lib/api/seats";

const POLL_INTERVAL_MS = 4000;

interface UseSeatMapOptions {
  flightId: string;
  sessionId: string;
  /** Seats already assigned to this booking (e.g. re-entering check-in) are
   * treated as "mine" rather than occupied-by-someone-else. */
  ownedSeatIds?: string[];
}

export function useSeatMap({ flightId, sessionId, ownedSeatIds = [] }: UseSeatMapOptions) {
  const [seats, setSeats] = useState<Seat[]>([]);
  const [loading, setLoading] = useState(true);
  const ownedRef = useRef(ownedSeatIds);
  useEffect(() => {
    ownedRef.current = ownedSeatIds;
  }, [ownedSeatIds]);

  const applyOwned = useCallback((raw: Seat[]): Seat[] => {
    if (ownedRef.current.length === 0) return raw;
    const ownedSet = new Set(ownedRef.current);
    return raw.map((seat) =>
      ownedSet.has(seat.id) ? { ...seat, status: "selected" as const } : seat
    );
  }, []);

  const fetchSeats = useCallback(async () => {
    try {
      const data = await seatsApi.getSeatMap(flightId, sessionId);
      setSeats(applyOwned(data));
    } catch {
      // Keep showing the last known map on a transient poll failure.
    } finally {
      setLoading(false);
    }
  }, [flightId, sessionId, applyOwned]);

  useEffect(() => {
    fetchSeats();
    const interval = setInterval(fetchSeats, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [fetchSeats]);

  const selectSeat = useCallback(
    async (seatId: string) => {
      // Optimistic update so the tap feels instant.
      setSeats((prev) =>
        prev.map((s) => (s.id === seatId ? { ...s, status: "selected" as const, lockedBy: sessionId } : s))
      );
      try {
        await seatsApi.lockSeat(flightId, seatId, sessionId);
      } finally {
        fetchSeats();
      }
    },
    [flightId, sessionId, fetchSeats]
  );

  const deselectSeat = useCallback(
    async (seatId: string) => {
      setSeats((prev) =>
        prev.map((s) => (s.id === seatId ? { ...s, status: "available" as const, lockedBy: undefined } : s))
      );
      try {
        await seatsApi.releaseSeat(flightId, seatId, sessionId);
      } finally {
        fetchSeats();
      }
    },
    [flightId, sessionId, fetchSeats]
  );

  const releaseAll = useCallback(() => {
    seatsApi.releaseAll(flightId, sessionId).catch(() => {});
  }, [flightId, sessionId]);

  return { seats, loading, selectSeat, deselectSeat, releaseAll, refresh: fetchSeats };
}
